-- Script para crear la base de datos ----> bd_parking_laprimera		              
-- Autores: Juan David Bohorquez Prieto, Kevin Julian Angarita Vega, Daniel Andres Galvis Marin, Ciro Sneider Olarte Carvajal               
-------------------------------------------------------------------------
-- 01.- BLOQUE CREAR BD
SELECT 'Paso 00: Bloque Crear BD_PARKING_LAPRIMERA .....'  AS paso, pg_sleep(10);
SELECT '.........................................'  AS paso, pg_sleep(0);
-------------------------------------------------------------------------

\! cls
\c postgres
SELECT 'Paso 01.1: Iniciando el Script .....'  AS paso, pg_sleep(01);

SELECT 'Paso 01.2: Listado de las BDs .....'  AS paso, pg_sleep(02);
\l

-- Eliminando la base de datos si existe
SELECT 'Paso 01.3: Eliminar BD_parking_laprimera si Existe .....'  AS paso, pg_sleep(05);
DROP DATABASE IF EXISTS bd_parking_laprimera;

\l

\! cls
SELECT 'Paso 01.4: Crear BD_parking_laprimera .....'  AS paso, pg_sleep(05);
CREATE DATABASE bd_parking_laprimera with ENCODING='UTF8';

SELECT 'Paso 01.5: Conectandose a bd_parking_laprimera .....'  AS paso, pg_sleep(05);
\c bd_parking_laprimera

-------------------------------------------------------------------------
-- 02.- BLOQUE DE CREACIÓN DE TABLAS
SELECT 'Paso 02: Bloque Crear TABLAS .....'  AS paso, pg_sleep(10);
SELECT '.........................................'  AS paso, pg_sleep(0);
-------------------------------------------------------------------------

-- TM_ESTADO
SELECT 'Paso 02.01: TMESTADO .....................'  AS paso, pg_sleep(05);

create table tm_estado(
    pkcods integer not null primary key,
    detalle_estado varchar(20) not null
);

insert into tm_estado(pkcods,detalle_estado) values (1,'ACTIVO'),(2,'INACTIVO'),(3,'DEBE'),(4,'NO DEBE');

-- TM_TIEMPO
SELECT 'Paso 02.02: TM_TIEMPO .....................'  AS paso, pg_sleep(03);

create table tm_tiempo(
    pkcod_tiempo serial not null primary key,
    detalle_tiempo varchar(40) not null,
    tiempo_minutos integer not null,
    fkcods_tiempo integer not null,
    foreign key(fkcods_tiempo) references tm_estado(pkcods) on update cascade on delete restrict
);

insert into tm_tiempo(detalle_tiempo, tiempo_minutos, fkcods_tiempo) values
('15 minutos', 15, 1),
('30 minutos', 30, 1),
('45 minutos', 45, 1),
('1 hora', 60, 1),
('1 dia', 1440, 1),
('1 semana', 10080, 1),
('1 mes', 43200, 1),
('1 año', 525600, 1);

-- TM_TIPO_VEHICULO
SELECT 'Paso 02.03: TM_TIPO_VEHICULO .....................'  AS paso, pg_sleep(05);

create table tm_tipo_vehiculo(
    pkid_tipo_vehiculo integer not null primary key,
    detalle_tipo_vehiculo varchar(50) not null,
    fkcods_tipo_vehiculo integer not null,
    foreign key(fkcods_tipo_vehiculo) references tm_estado(pkcods) on update cascade on delete restrict
);

insert into tm_tipo_vehiculo(pkid_tipo_vehiculo,detalle_tipo_vehiculo,fkcods_tipo_vehiculo) values 
(1000, 'Carro', 1),
(2000, 'Moto', 1);

-- TM_CLIENTE
SELECT 'Paso 02.04: TM_CLIENTE .....................'  AS paso, pg_sleep(02);

create table tm_cliente(
    pkc_cliente varchar(12) not null primary key,
    nombre_cliente varchar(50) not null,
    apellido_cliente varchar(50) not null,
    telefono_cliente varchar(15) not null,
    fkcods_cliente integer not null,
    foreign key(fkcods_cliente) references tm_estado(pkcods) on update cascade on delete restrict
);

Insert into tm_cliente(pkc_cliente,nombre_cliente,apellido_cliente,telefono_cliente,fkcods_cliente) values
('1012345678', 'Juan', 'Pérez', '3004567890', 1),
('1023456789', 'María', 'Gómez', '3012345678', 1),
('1034567890', 'Carlos', 'López', '3023456781', 1),
('1045678901', 'Ana', 'Martínez', '3009876543', 1),
('1056789012', 'Luis', 'Rodríguez', '3156782345', 1),
('1067890123', 'Valentina', 'Hernández', '3167890123', 1),
('1078901234', 'Andrés', 'Ramírez', '3115678901', 1),
('1089012345', 'Diana', 'Castro', '3146789012', 1),
('1090123456', 'Miguel', 'Cárdenas', '3203456789', 1),
('1101234567', 'Laura', 'Moreno', '3134567890', 1),
('1112345678', 'Santiago', 'Torres', '3226789012', 1),
('1123456789', 'Camila', 'Ortega', '3127894561', 1),
('1134567890', 'Felipe', 'Guerrero', '3172345678', 1),
('1145678901', 'Paula', 'Rojas', '3198765432', 1),
('1156789012', 'Daniel', 'Santos', '3213456789', 1),
('1167890123', 'Isabela', 'Vargas', '3209876543', 1),
('1178901234', 'Sebastián', 'Mendoza', '3187654321', 1),
('1189012345', 'Natalia', 'Pineda', '3165432187', 1),
('1190123456', 'Oscar', 'Salazar', '3152345678', 1),
('1201234567', 'Luisa', 'Fernández', '3109876543', 1);

-- TM_TIPO_SERVICIO
SELECT 'Paso 02.05: TM_TIPO_SERVICIO .....................'  AS paso, pg_sleep(04);

create table tm_tipo_servicio(
    pkcod_tipo_servicio integer not null primary key,
    detalle_tipo_servicio varchar(30) not null,
    fkcods_tipo_servicio integer not null,
    foreign key(fkcods_tipo_servicio) references tm_estado(pkcods) on update cascade on delete restrict
);

insert into tm_tipo_servicio(pkcod_tipo_servicio,detalle_tipo_servicio, fkcods_tipo_servicio) values
(1, 'normal', 1),
(2, 'media mensualidad', 1),
(3, 'mensualidad', 1);

-- TM_EMPLEADO
SELECT 'Paso 02.06: TM_EMPLEADO .....................'  AS paso, pg_sleep(03);

create table tm_empleado(
    pkc_empleado varchar(12) not null primary key,
    nombre_empleado varchar(50) not null,
    apellido_empleado varchar(50) not null,
    telefono_empleado varchar(15) not null,
    usuario_empleado varchar(20) not null,
    clave_empleado varchar(15) not null,
    nivel_empleado integer not null,
    fkcods_empleado integer not null,
    foreign key(fkcods_empleado) references tm_estado(pkcods) on update cascade on delete restrict
);

Insert into tm_empleado(pkc_empleado,nombre_empleado,apellido_empleado,telefono_empleado,usuario_empleado,clave_empleado,nivel_empleado,fkcods_empleado) values
('1234567890','Jair','Angarita Bustos','3123456781','noniman','admin123',1,1),
('1234567891','Kevin Julian','Angarita Vega','3100000002','overgame','pass123',2,1);

-- TM_VEHICULO
SELECT 'Paso 02.07: TM_VEHICULO .....................'  AS paso, pg_sleep(05);

create table tm_vehiculo(
    pkplaca_vehiculo varchar(20) not null primary key,
    detalle_vehiculo varchar(30) not null,
    fkid_tipo_vehiculo integer not null,
    fkc_cliente varchar(12),
    fkcods_vehiculo integer not null,
    foreign key(fkid_tipo_vehiculo) references tm_tipo_vehiculo(pkid_tipo_vehiculo) on update cascade on delete restrict,
    foreign key(fkc_cliente) references tm_cliente(pkc_cliente) on update cascade on delete restrict,
    foreign key(fkcods_vehiculo) references tm_estado(pkcods) on update cascade on delete restrict
);

Insert into tm_vehiculo(pkplaca_vehiculo,detalle_vehiculo,fkid_tipo_vehiculo,fkc_cliente,fkcods_vehiculo) values
('ABC123', 'Toyota Corolla', 1000, '1012345678', 1),
('DEF456', 'Honda Civic', 1000, '1023456789', 1),
('GHI789', 'Ford Fiesta', 1000, '1034567890', 1),
('JKL234', 'Chevrolet Spark', 1000, '1045678901', 1),
('MNO567', 'Nissan Versa', 1000, '1056789012', 1),
('PQR890', 'Volkswagen Gol', 1000, '1067890123', 1),
('STU345', 'Hyundai i10', 1000, '1078901234', 1),
('VWX678', 'Kia Picanto', 1000, '1089012345', 1),
('YZA901', 'Mazda 3', 1000, '1090123456', 1),
('BCD234', 'BMW Serie 1', 1000, '1101234567', 1),
('EFG12A', 'Honda CB125F', 2000, '1112345678', 1),
('HIJ34B', 'Yamaha FZ 2.0', 2000, '1123456789', 1),
('KLM56C', 'Kawasaki Z250', 2000, '1134567890', 1),
('NOP78D', 'Suzuki Gixxer', 2000, '1145678901', 1),
('QRS90E', 'KTM Duke 200', 2000, '1156789012', 1),
('TUV12F', 'Ducati Monster 797', 2000, '1167890123', 1),
('WXY34G', 'Harley Street 750', 2000, '1178901234', 1),
('ZAB56H', 'Triumph Street Twin', 2000, '1189012345', 1),
('CDE78I', 'Royal Enfield Classic 350', 2000, '1190123456', 1),
('FGH90J', 'Bajaj Pulsar NS200', 2000, '1201234567', 1);

-- TM_TARIFA
SELECT 'Paso 02.08: TM_TARIFA .....................'  AS paso, pg_sleep(03);

create table tm_tarifa(
    pkid_tarifa varchar(10) not null primary key,
    detalle_tarifa varchar(30) not null,
    valor_tarifa decimal(15,2) not null,
    fkcod_tipo_servicio integer not null,
    fkid_tipo_vehiculo integer not null,
    fkcod_tiempo integer not null,
    fkcods_tarifa integer not null,
    foreign key(fkcod_tipo_servicio) references tm_tipo_servicio(pkcod_tipo_servicio) on update cascade on delete restrict,
    foreign key(fkid_tipo_vehiculo) references tm_tipo_vehiculo(pkid_tipo_vehiculo) on update cascade on delete restrict,
    foreign key(fkcod_tiempo) references tm_tiempo(pkcod_tiempo) on update cascade on delete restrict,
    foreign key(fkcods_tarifa) references tm_estado(pkcods) on update cascade on delete restrict
);

insert into tm_tarifa(pkid_tarifa,detalle_tarifa,valor_tarifa,fkcod_tipo_servicio,fkid_tipo_vehiculo,fkcod_tiempo,fkcods_tarifa) values
('TAR101', 'Carro 15 min', 1200, 1, 1000, 1, 1),
('TAR102', 'Carro 30 min', 2000, 1, 1000, 2, 1),
('TAR103', 'Carro 45 min', 3200, 1, 1000, 3, 1),
('TAR104', 'Carro 1 hora', 4000, 1, 1000, 4, 1),
('TAR105', 'Carro media mensualidad', 70000, 2, 1000, 7, 1),
('TAR106', 'Carro mensualidad', 140000, 3, 1000, 7, 1),
('TAR201', 'Moto 15 min', 900, 1, 2000, 1, 1),
('TAR202', 'Moto 30 min', 1000, 1, 2000, 2, 1),
('TAR203', 'Moto 45 min', 1200, 1, 2000, 3, 1),
('TAR204', 'Moto 1 hora', 1300, 1, 2000, 4, 1),
('TAR205', 'Moto media mensualidad', 35000, 2, 2000, 7, 1),
('TAR206', 'Moto mensualidad', 70000, 3, 2000, 7, 1);

-- TD_PAGOS
SELECT 'Paso 02.09: TD_PAGOS .....................'  AS paso, pg_sleep(04);

create table td_pagos(
    pkid_pago varchar(10) not null primary key,
    fecha_pago date not null,
    monto_pagado decimal(15,2) not null,
    fkc_cliente varchar(12) not null,
    fkcods_pagos integer not null,
    foreign key(fkc_cliente) references tm_cliente(pkc_cliente) on update cascade on delete restrict,
    foreign key(fkcods_pagos) references tm_estado(pkcods) on update cascade on delete restrict
);

insert into td_pagos(pkid_pago,fecha_pago,monto_pagado,fkc_cliente,fkcods_pagos) values
('PAG001', CURRENT_DATE, 4000, '1012345678', 1),
('PAG002', CURRENT_DATE, 2000, '1023456789', 1),
('PAG003', CURRENT_DATE, 6000, '1034567890', 1),
('PAG004', CURRENT_DATE, 8000, '1045678901', 1),
('PAG005', CURRENT_DATE, 1200, '1056789012', 1);

-- TD_REGISTROS
SELECT 'Paso 02.10: TD_REGISTROS .....................'  AS paso, pg_sleep(05);

create table td_registros(
    pkid_registro varchar(10) not null primary key,
    fecha_entrada date not null,
    hora_entrada time,
    fecha_salida date,
    hora_salida time,
    fkplaca_vehiculo varchar(20) not null,
    fkid_pago varchar(20),
    fkc_empleado varchar(12),
    fkid_tarifa varchar(10),
    fkcod_tipo_servicio integer,
    fkcods_registro integer not null,
    foreign key(fkplaca_vehiculo) references tm_vehiculo(pkplaca_vehiculo) on update cascade on delete restrict,
    foreign key(fkid_pago) references td_pagos(pkid_pago) on update cascade on delete restrict,
    foreign key(fkc_empleado) references tm_empleado(pkc_empleado) on update cascade on delete restrict,
    foreign key(fkid_tarifa) references tm_tarifa(pkid_tarifa) on update cascade on delete restrict,
    foreign key(fkcod_tipo_servicio) references tm_tipo_servicio(pkcod_tipo_servicio) on update cascade on delete restrict,
    foreign key(fkcods_registro) references tm_estado(pkcods) on update cascade on delete restrict
);

insert into td_registros(pkid_registro,fecha_entrada,hora_entrada,fecha_salida,hora_salida,fkplaca_vehiculo,fkid_pago,fkc_empleado,fkid_tarifa,fkcod_tipo_servicio,fkcods_registro) values
('REG001', CURRENT_DATE, '08:00:00', NULL, NULL, 'ABC123', 'PAG001', '1234567890', 'TAR104', 1, 1),
('REG002', CURRENT_DATE, '09:30:00', NULL, NULL, 'DEF456', 'PAG002', '1234567890', 'TAR102', 1, 1),
('REG003', CURRENT_DATE, '07:45:00', NULL, NULL, 'GHI789', 'PAG003', '1234567890', 'TAR104', 1, 1),
('REG004', CURRENT_DATE, '12:15:00', NULL, NULL, 'JKL234', 'PAG004', '1234567890', 'TAR106', 3, 1),
('REG005', CURRENT_DATE, '14:00:00', NULL, NULL, 'MNO567', 'PAG005', '1234567890', 'TAR101', 1, 1);

-------------------------------------------------------------------------
-- 03.- FUNCIONES
SELECT 'Paso 03: Bloque Crear FUNCIONES .....'  AS paso, pg_sleep(10);
SELECT '.........................................'  AS paso, pg_sleep(0);
-------------------------------------------------------------------------

-- Funcion para calcular el total recaudado en un dia
SELECT 'Paso 03.01: Funcion ftotal_recaudado_dia .....................'  AS paso, pg_sleep(03);

CREATE OR REPLACE FUNCTION ftotal_recaudado_dia(xfecha date)
RETURNS numeric(15,2) AS $$
DECLARE
    total_monto numeric(15,2);
BEGIN
    total_monto := (SELECT SUM(monto_pagado) 
    FROM td_pagos
    WHERE fecha_pago = xfecha);

    IF total_monto IS NULL THEN
        total_monto := 0;
    END IF;

    RETURN total_monto;
END;
$$ LANGUAGE plpgsql;

-- Funcion para calcular la tarifa segun el tiempo de estadia
SELECT 'Paso 03.02: Funcion fcalcular_tarifa .....................'  AS paso, pg_sleep(03);

CREATE OR REPLACE FUNCTION fcalcular_tarifa(
    xfecha_entrada date,
    xhora_entrada time,
    xfecha_salida date,
    xhora_salida time,
    xtipo_vehiculo integer,
    xtipo_servicio integer
) RETURNS numeric(15,2) AS $$
DECLARE
    v_duracion_minutos integer;
    v_horas_completas integer;
    v_minutos_restantes integer;
    v_tiempo_fraccion_cobrar integer;
    v_tarifa_hora numeric(15,2);
    v_tarifa_fraccion numeric(15,2);
    v_tarifa_total numeric(15,2);
    v_margen_anticipacion integer;
BEGIN
    v_tarifa_total := 0;
    v_margen_anticipacion := 3;

    v_duracion_minutos := EXTRACT(EPOCH FROM ((xfecha_salida + xhora_salida)::timestamp - (xfecha_entrada + xhora_entrada)::timestamp)) / 60;

    IF v_duracion_minutos < 0 THEN
        v_duracion_minutos := 0;
    END IF;

    IF xtipo_servicio = 1 THEN
        SELECT valor_tarifa INTO v_tarifa_hora
        FROM tm_tarifa t
        JOIN tm_tiempo tm ON t.fkcod_tiempo = tm.pkcod_tiempo
        WHERE t.fkid_tipo_vehiculo = xtipo_vehiculo
          AND t.fkcod_tipo_servicio = 1
          AND tm.tiempo_minutos = 60;

        IF v_duracion_minutos <= 60 THEN
            v_duracion_minutos := v_duracion_minutos + v_margen_anticipacion;

            IF v_duracion_minutos <= 15 THEN
                v_tiempo_fraccion_cobrar := 15;
            ELSIF v_duracion_minutos <= 30 THEN
                v_tiempo_fraccion_cobrar := 30;
            ELSIF v_duracion_minutos <= 45 THEN
                v_tiempo_fraccion_cobrar := 45;
            ELSE
                v_tiempo_fraccion_cobrar := 60;
            END IF;

            SELECT valor_tarifa INTO v_tarifa_total
            FROM tm_tarifa t
            JOIN tm_tiempo tm ON t.fkcod_tiempo = tm.pkcod_tiempo
            WHERE t.fkid_tipo_vehiculo = xtipo_vehiculo
              AND t.fkcod_tipo_servicio = 1
              AND tm.tiempo_minutos = v_tiempo_fraccion_cobrar;

        ELSE
            v_horas_completas := FLOOR(v_duracion_minutos / 60);
            v_minutos_restantes := v_duracion_minutos % 60;

            v_tarifa_total := v_horas_completas * v_tarifa_hora;

            IF v_minutos_restantes > 0 THEN
                v_minutos_restantes := v_minutos_restantes + v_margen_anticipacion;

                IF v_minutos_restantes <= 15 THEN
                    v_tiempo_fraccion_cobrar := 15;
                ELSIF v_minutos_restantes <= 30 THEN
                    v_tiempo_fraccion_cobrar := 30;
                ELSIF v_minutos_restantes <= 45 THEN
                    v_tiempo_fraccion_cobrar := 45;
                ELSE
                    v_tiempo_fraccion_cobrar := 60;
                END IF;

                SELECT valor_tarifa INTO v_tarifa_fraccion
                FROM tm_tarifa t
                JOIN tm_tiempo tm ON t.fkcod_tiempo = tm.pkcod_tiempo
                WHERE t.fkid_tipo_vehiculo = xtipo_vehiculo
                  AND t.fkcod_tipo_servicio = 1
                  AND tm.tiempo_minutos = v_tiempo_fraccion_cobrar;

                v_tarifa_total := v_tarifa_total + COALESCE(v_tarifa_fraccion, 0);
            END IF;
        END IF;

    ELSE
        SELECT valor_tarifa INTO v_tarifa_total
        FROM tm_tarifa
        WHERE fkid_tipo_vehiculo = xtipo_vehiculo
          AND fkcod_tipo_servicio = xtipo_servicio
        LIMIT 1;
    END IF;

    RETURN COALESCE(v_tarifa_total, 0);
END;
$$ LANGUAGE plpgsql;

-------------------------------------------------------------------------
-- 04.- TRIGGERS
SELECT 'Paso 04: Bloque Crear TRIGGERS .....'  AS paso, pg_sleep(10);
SELECT '.........................................'  AS paso, pg_sleep(0);
-------------------------------------------------------------------------

-- Trigger para actualizar el estado del pago
SELECT 'Paso 04.01: Trigger trg_actualizar_estado_pago .....................'  AS paso, pg_sleep(03);

CREATE OR REPLACE FUNCTION actualizar_estado_pago()
RETURNS trigger AS $$
DECLARE
    v_valor_tarifa decimal(15,2);
    v_monto_pagado decimal(15,2);
BEGIN
    SELECT valor_tarifa 
    INTO v_valor_tarifa
    FROM tm_tarifa
    WHERE pkid_tarifa = NEW.fkid_tarifa;

    SELECT monto_pagado
    INTO v_monto_pagado
    FROM td_pagos
    WHERE pkid_pago = NEW.fkid_pago;

    IF v_monto_pagado >= v_valor_tarifa THEN
        UPDATE td_pagos
        SET fkcods_pagos = 4  
        WHERE pkid_pago = NEW.fkid_pago;
    ELSE
        UPDATE td_pagos
        SET fkcods_pagos = 3  
        WHERE pkid_pago = NEW.fkid_pago;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_actualizar_estado_pago
AFTER INSERT ON td_registros
FOR EACH ROW
EXECUTE FUNCTION actualizar_estado_pago();

-- Trigger para validar que no se duplique la placa del vehiculo
SELECT 'Paso 04.02: Trigger trg_validar_vehiculo .....................'  AS paso, pg_sleep(03);

CREATE OR REPLACE FUNCTION fn_validar_vehiculo()
RETURNS trigger AS $$
BEGIN
    IF EXISTS (SELECT 1 FROM tm_vehiculo WHERE pkplaca_vehiculo = NEW.pkplaca_vehiculo) THEN
        RAISE EXCEPTION 'La placa % ya existe en el sistema', NEW.pkplaca_vehiculo;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_validar_vehiculo
BEFORE INSERT ON tm_vehiculo
FOR EACH ROW
EXECUTE FUNCTION fn_validar_vehiculo();

-------------------------------------------------------------------------
-- 05.- VISTAS
SELECT 'Paso 05: Bloque Crear VISTAS .....'  AS paso, pg_sleep(10);
SELECT '.........................................'  AS paso, pg_sleep(0);
-------------------------------------------------------------------------

-- Vista: Clientes con sus vehiculos y servicios
SELECT 'Paso 05.01: Vista v_cliente_vehiculo_servicio .....................'  AS paso, pg_sleep(03);

CREATE OR REPLACE VIEW v_cliente_vehiculo_servicio AS
SELECT 
    c.pkc_cliente AS cedula,
    c.nombre_cliente AS nombre,
    c.apellido_cliente AS apellido,
    c.telefono_cliente AS telefono,
    v.pkplaca_vehiculo AS placa,
    tv.detalle_tipo_vehiculo AS tipo_vehiculo,
    ts.detalle_tipo_servicio AS tipo_servicio,
    e.detalle_estado AS estado_cliente
FROM tm_cliente c
LEFT JOIN tm_vehiculo v ON c.pkc_cliente = v.fkc_cliente
LEFT JOIN tm_tipo_vehiculo tv ON v.fkid_tipo_vehiculo = tv.pkid_tipo_vehiculo
LEFT JOIN tm_tipo_servicio ts ON ts.pkcod_tipo_servicio = 1
LEFT JOIN tm_estado e ON c.fkcods_cliente = e.pkcods
ORDER BY c.nombre_cliente;

SELECT 'CONSULTA 8: Tarifas disponibles' AS info;
SELECT 
    t.pkid_tarifa,
    t.detalle_tarifa,
    t.valor_tarifa,
    tv.detalle_tipo_vehiculo AS tipo_vehiculo,
    ts.detalle_tipo_servicio AS tipo_servicio,
    tm.detalle_tiempo AS duracion
FROM tm_tarifa t
JOIN tm_tipo_vehiculo tv ON t.fkid_tipo_vehiculo = tv.pkid_tipo_vehiculo
JOIN tm_tipo_servicio ts ON t.fkcod_tipo_servicio = ts.pkcod_tipo_servicio
JOIN tm_tiempo tm ON t.fkcod_tiempo = tm.pkcod_tiempo
ORDER BY tv.detalle_tipo_vehiculo, ts.detalle_tipo_servicio;.nombre_cliente;

-- Vista: Registros activos
SELECT 'Paso 05.02: Vista v_registros_activos .....................'  AS paso, pg_sleep(03);

CREATE OR REPLACE VIEW v_registros_activos AS
SELECT 
    r.pkid_registro AS id_registro,
    r.fecha_entrada,
    r.hora_entrada,
    v.pkplaca_vehiculo AS placa,
    c.pkc_cliente AS cedula_cliente,
    c.nombre_cliente,
    c.telefono_cliente,
    tv.detalle_tipo_vehiculo AS tipo_vehiculo,
    ts.detalle_tipo_servicio AS tipo_servicio,
    e.detalle_estado AS estado_registro,
    (CURRENT_TIMESTAMP - (r.fecha_entrada::timestamp + r.hora_entrada::time)) AS tiempo_transcurrido
FROM td_registros r
LEFT JOIN tm_vehiculo v ON r.fkplaca_vehiculo = v.pkplaca_vehiculo
LEFT JOIN tm_cliente c ON v.fkc_cliente = c.pkc_cliente
LEFT JOIN tm_tipo_vehiculo tv ON v.fkid_tipo_vehiculo = tv.pkid_tipo_vehiculo
LEFT JOIN tm_tipo_servicio ts ON r.fkcod_tipo_servicio = ts.pkcod_tipo_servicio
LEFT JOIN tm_estado e ON r.fkcods_registro = e.pkcods
WHERE r.hora_salida IS NULL
ORDER BY r.fecha_entrada DESC, r.hora_entrada DESC;

-------------------------------------------------------------------------
-- 06.- CONSULTAS DE VERIFICACION
SELECT 'Paso 06: Bloque CONSULTAS DE VERIFICACION .....'  AS paso, pg_sleep(10);
SELECT '.........................................'  AS paso, pg_sleep(0);
-------------------------------------------------------------------------

SELECT 'CONSULTA 1: Clientes con sus vehiculos y servicios' AS info;
SELECT * FROM v_cliente_vehiculo_servicio;

SELECT 'CONSULTA 2: Registros activos (vehiculos dentro del parqueadero)' AS info;
SELECT * FROM v_registros_activos;

SELECT 'CONSULTA 3: Cantidad de clientes registrados' AS info;
SELECT COUNT(*) AS total_clientes FROM tm_cliente;

SELECT 'CONSULTA 4: Cantidad de vehiculos registrados' AS info;
SELECT COUNT(*) AS total_vehiculos FROM tm_vehiculo;

SELECT 'CONSULTA 5: Tipos de servicios disponibles' AS info;
SELECT * FROM tm_tipo_servicio;

SELECT 'CONSULTA 6: Todos los clientes (listado simple)' AS info;
SELECT 
    pkc_cliente AS cedula,
    nombre_cliente AS nombre,
    apellido_cliente AS apellido,
    telefono_cliente AS telefono,
    CASE WHEN fkcods_cliente = 1 THEN 'ACTIVO' ELSE 'INACTIVO' END AS estado
FROM tm_cliente
ORDER BY nombre_cliente;

SELECT 'CONSULTA 7: Vehiculos registrados por cliente' AS info;
SELECT 
    c.nombre_cliente AS cliente,
    v.pkplaca_vehiculo AS placa,
    v.detalle_vehiculo AS modelo,
    tv.detalle_tipo_vehiculo AS tipo
FROM tm_vehiculo v
JOIN tm_cliente c ON v.fkc_cliente = c.pkc_cliente
JOIN tm_tipo_vehiculo tv ON v.fkid_tipo_vehiculo = tv.pkid_tipo_vehiculo
ORDER BY c
package com.parking.proyecto.dto;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

/**
 * DTO para recibir datos del formulario de registro de vehículo
 * Compatible con registrarVehiculo.html
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RegistroVehiculoRequest {
    
    // Datos del vehículo
    private String placa;
    private Integer tipoVehiculo;      // 1000 = Carro, 2000 = Moto
    private String detalleVehiculo;
    
    // Datos del servicio
    private Integer tipoServicio;      // 1 = Normal, 2 = Media mensualidad, 3 = Mensualidad
    
    // Datos del cliente (opcionales para servicio normal)
    private String cedula;
    private String nombre;
    private String apellido;
    private String telefono;
    
    // Empleado que registra (opcional, se asigna por defecto)
    private String empleado;
    
    /**
     * Valida que los datos mínimos estén presentes
     */
    public boolean esValido() {
        return placa != null && !placa.trim().isEmpty() &&
               tipoVehiculo != null &&
               tipoServicio != null;
    }
    
    /**
     * Valida si requiere datos de cliente (mensualidades)
     */
    public boolean requiereDatosCliente() {
        return tipoServicio != null && tipoServicio > 1; // 2 o 3 = mensualidades
    }
}
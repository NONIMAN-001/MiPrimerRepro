package com.parking.proyecto.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LoginResponse {
    private boolean success;
    private String mensaje;
    private String redirectUrl;
    private UsuarioInfo usuario;
    
    @Data
    @Builder
    public static class UsuarioInfo {
        private String cedula;
        private String nombre;
        private String apellido;
        private String usuario;
        private Integer nivel;
    }
    
    public static LoginResponse success(UsuarioInfo usuario) {
        return LoginResponse.builder()
                .success(true)
                .mensaje("Login exitoso")
                .redirectUrl("/home")
                .usuario(usuario)
                .build();
    }
    
    public static LoginResponse error(String mensaje) {
        return LoginResponse.builder()
                .success(false)
                .mensaje(mensaje)
                .redirectUrl(null)
                .usuario(null)
                .build();
    }
}
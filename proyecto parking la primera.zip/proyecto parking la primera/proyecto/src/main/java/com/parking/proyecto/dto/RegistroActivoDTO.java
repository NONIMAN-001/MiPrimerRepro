package com.parking.proyecto.dto;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Builder;
import java.time.LocalDate;
import java.time.LocalTime;

/**
 * DTO para representar un registro activo
 * Compatible con la vista v_registros_activos
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RegistroActivoDTO {
    
    private Long pkcodsRegistro;
    private String fkplacaVehiculo;
    private String tipoVehiculo;
    private String tipoServicio;
    
    private LocalDate fechaEntrada;
    private LocalTime horaEntrada;
    
    // Datos del cliente (si existen)
    private String nombreCliente;
    private String cedulaCliente;
    private String telefonoCliente;
    
    private String empleadoRegistro;
    private String estado;
}

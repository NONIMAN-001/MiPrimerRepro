package com.parking.proyecto.controllers;

import com.parking.proyecto.dto.*;
import com.parking.proyecto.service.ParqueaderoService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Controlador REST para operaciones del parqueadero
 * Todos los endpoints son invocados desde JavaScript en las vistas HTML
 */
@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class RegistroController {
    
    private final ParqueaderoService service;
    
    /**
     * POST /api/registrar-vehiculo
     * Registra entrada de vehículo
     * 
     * Invocado desde: registrarVehiculo.html
     */
    @PostMapping("/registrar-vehiculo")
    public ResponseEntity<Map<String, Object>> registrarVehiculo(
            @RequestBody RegistroVehiculoRequest request) {
        
        Map<String, Object> resultado = service.registrarVehiculo(request);
        
        if ((Boolean) resultado.get("success")) {
            return ResponseEntity.ok(resultado);
        } else {
            return ResponseEntity.badRequest().body(resultado);
        }
    }
    
    /**
     * GET /api/info-cobro/{placa}
     * Obtiene información para cobrar a un cliente
     * 
     * Invocado desde: cobrarCliente.html (función buscarClientePorPlaca)
     */
    @GetMapping("/info-cobro/{placa}")
    public ResponseEntity<InfoCobroResponse> obtenerInfoCobro(@PathVariable String placa) {
        
        InfoCobroResponse info = service.obtenerInfoCobro(placa);
        
        if (info.isSuccess()) {
            return ResponseEntity.ok(info);
        } else {
            return ResponseEntity.badRequest().body(info);
        }
    }
    
    /**
     * POST /api/cobrar-cliente
     * Procesa el cobro y cierra el registro
     * 
     * Invocado desde: cobrarCliente.html (submit del formulario)
     */
    @PostMapping("/cobrar-cliente")
    public ResponseEntity<Map<String, Object>> cobrarCliente(
            @RequestBody CobrarClienteRequest request) {
        
        Map<String, Object> resultado = service.cobrarCliente(request);
        
        if ((Boolean) resultado.get("success")) {
            return ResponseEntity.ok(resultado);
        } else {
            return ResponseEntity.badRequest().body(resultado);
        }
    }
    
    /**
     * GET /api/registros-activos
     * Obtiene todos los registros sin salida
     * 
     * Invocado desde: registros.html o home.html
     */
    @GetMapping("/registros-activos")
    public ResponseEntity<List<RegistroActivoDTO>> obtenerRegistrosActivos() {
        return ResponseEntity.ok(service.obtenerRegistrosActivos());
    }
    
    /**
     * GET /api/ingresos-dia
     * Obtiene el total de ingresos del día actual
     * 
     * Invocado desde: registros.html
     */
    @GetMapping("/ingresos-dia")
    public ResponseEntity<Map<String, Object>> obtenerIngresosDia() {
        return ResponseEntity.ok(service.obtenerIngresosDia());
    }
    
    /**
     * GET /api/sistema/tarifas-disponibles
     * Obtiene todas las tarifas configuradas
     * 
     * Invocado desde: cobrarCliente.html (función obtenerTarifaYCalcularCobro)
     */
    @GetMapping("/sistema/tarifas-disponibles")
    public ResponseEntity<Map<String, Object>> obtenerTarifas() {
        List<Map<String, Object>> tarifas = service.obtenerTarifasDisponibles();
        
        return ResponseEntity.ok(Map.of(
            "success", true,
            "tarifas", tarifas
        ));
    }
    
    /**
     * GET /api/registros/activo/{placa}
     * Busca un registro activo específico por placa
     * 
     * Invocado desde: cobrarCliente.html
     */
    @GetMapping("/registros/activo/{placa}")
    public ResponseEntity<Map<String, Object>> buscarRegistroActivo(@PathVariable String placa) {
        
        InfoCobroResponse info = service.obtenerInfoCobro(placa);
        
        if (info.isSuccess()) {
            // Construir respuesta compatible con el frontend
            Map<String, Object> registro = Map.of(
                "fkcodTipoServicio", info.getTipoServicio(),
                "fechaEntrada", info.getFechaEntrada().toLocalDate(),
                "horaEntrada", info.getHoraEntrada()
            );
            
            return ResponseEntity.ok(Map.of(
                "success", true,
                "registro", registro
            ));
        } else {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "mensaje", info.getMensaje()
            ));
        }
    }
}
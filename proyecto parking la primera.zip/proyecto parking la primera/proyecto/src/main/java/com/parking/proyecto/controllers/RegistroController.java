package com.parking.proyecto.controllers;

import com.parking.proyecto.dto.*;
import com.parking.proyecto.models.Empleado;
import com.parking.proyecto.repository.EmpleadoRepository;
import com.parking.proyecto.service.ParqueaderoService;

import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Optional; // ¡FALTABA ESTA IMPORTACIÓN!

/**
 * Controlador REST para operaciones del parqueadero
 * Todos los endpoints son invocados desde JavaScript en las vistas HTML
 */
@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class RegistroController {
    
    private final ParqueaderoService service;
    private final EmpleadoRepository empleadoRepository;
    
    /**
     * POST /api/registrar-vehiculo
     * Registra entrada de vehículo
     * 
     * Invocado desde: registrarVehiculo.html
     */
    @PostMapping("/registrar-vehiculo")
    public ResponseEntity<Map<String, Object>> registrarVehiculo(
            @RequestBody RegistroVehiculoRequest request) {
        
        Map<String, Object> resultado = service.registrarVehiculo(request);
        
        if ((Boolean) resultado.get("success")) {
            return ResponseEntity.ok(resultado);
        } else {
            return ResponseEntity.badRequest().body(resultado);
        }
    }
    
    /**
     * GET /api/info-cobro/{placa}
     * Obtiene información para cobrar a un cliente
     * 
     * Invocado desde: cobrarCliente.html (función buscarClientePorPlaca)
     */
    @GetMapping("/info-cobro/{placa}")
    public ResponseEntity<InfoCobroResponse> obtenerInfoCobro(@PathVariable String placa) {
        
        InfoCobroResponse info = service.obtenerInfoCobro(placa);
        
        if (info.isSuccess()) {
            return ResponseEntity.ok(info);
        } else {
            return ResponseEntity.badRequest().body(info);
        }
    }
    
    /**
     * POST /api/cobrar-cliente
     * Procesa el cobro y cierra el registro
     * 
     * Invocado desde: cobrarCliente.html (submit del formulario)
     */
    @PostMapping("/cobrar-cliente")
    public ResponseEntity<Map<String, Object>> cobrarCliente(
            @RequestBody CobrarClienteRequest request) {
        
        Map<String, Object> resultado = service.cobrarCliente(request);
        
        if ((Boolean) resultado.get("success")) {
            return ResponseEntity.ok(resultado);
        } else {
            return ResponseEntity.badRequest().body(resultado);
        }
    }
    
    /**
     * GET /api/registros-activos
     * Obtiene todos los registros sin salida
     * 
     * Invocado desde: registros.html o home.html
     */
    @GetMapping("/registros-activos")
    public ResponseEntity<List<RegistroActivoDTO>> obtenerRegistrosActivos() {
        return ResponseEntity.ok(service.obtenerRegistrosActivos());
    }
    
    /**
     * GET /api/ingresos-dia
     * Obtiene el total de ingresos del día actual
     * 
     * Invocado desde: registros.html
     */
    @GetMapping("/ingresos-dia")
    public ResponseEntity<Map<String, Object>> obtenerIngresosDia() {
        return ResponseEntity.ok(service.obtenerIngresosDia());
    }
    
    /**
     * GET /api/sistema/tarifas-disponibles
     * Obtiene todas las tarifas configuradas
     * 
     * Invocado desde: cobrarCliente.html (función obtenerTarifaYCalcularCobro)
     */
    @GetMapping("/sistema/tarifas-disponibles")
    public ResponseEntity<Map<String, Object>> obtenerTarifas() {
        List<Map<String, Object>> tarifas = service.obtenerTarifasDisponibles();
        
        return ResponseEntity.ok(Map.of(
            "success", true,
            "tarifas", tarifas
        ));
    }
    
    /**
     * GET /api/registros/activo/{placa}
     * Busca un registro activo específico por placa
     * 
     * Invocado desde: cobrarCliente.html
     */
    @GetMapping("/registros/activo/{placa}")
    public ResponseEntity<Map<String, Object>> buscarRegistroActivo(@PathVariable String placa) {
        
        InfoCobroResponse info = service.obtenerInfoCobro(placa);
        
        if (info.isSuccess()) {
            // Construir respuesta compatible con el frontend
            Map<String, Object> registro = Map.of(
                "fkcodTipoServicio", info.getTipoServicio(),
                "fechaEntrada", info.getFechaEntrada().toLocalDate(),
                "horaEntrada", info.getHoraEntrada()
            );
            
            return ResponseEntity.ok(Map.of(
                "success", true,
                "registro", registro
            ));
        } else {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "mensaje", info.getMensaje()
            ));
        }
    }

    /**
     * POST /api/registrar-usuario
     * Registra un nuevo empleado/usuario
     */
    @PostMapping("/registrar-usuario")
    public ResponseEntity<Map<String, Object>> registrarUsuario(
            @RequestBody Map<String, String> request) {
        
        Map<String, Object> respuesta = new HashMap<>();
        
        try {
            String username = request.get("username");
            String email = request.get("email"); // Puedes quitar esto si no lo usas
            String phone = request.get("phone");
            String password = request.get("password");
            String confirmPassword = request.get("confirm_password");
            
            // Validar que las contraseñas coincidan
            if (!password.equals(confirmPassword)) {
                respuesta.put("success", false);
                respuesta.put("mensaje", "Las contraseñas no coinciden");
                return ResponseEntity.badRequest().body(respuesta);
            }
            
            // Verificar si el usuario ya existe
            if (empleadoRepository.existsByUsuario(username)) {
                respuesta.put("success", false);
                respuesta.put("mensaje", "El nombre de usuario ya está en uso");
                return ResponseEntity.badRequest().body(respuesta);
            }
            
            // Generar cédula automática
            String cedula = generarCedula();
            
            // Crear nuevo empleado
            Empleado nuevoEmpleado = new Empleado();
            nuevoEmpleado.setCedula(cedula);
            nuevoEmpleado.setNombre(extraerNombre(username));
            nuevoEmpleado.setApellido("Usuario");
            nuevoEmpleado.setTelefono(phone);
            nuevoEmpleado.setUsuario(username);
            nuevoEmpleado.setClave(password);
            nuevoEmpleado.setNivel(2);
            nuevoEmpleado.setEstado(1);
            
            // Guardar en la base de datos
            empleadoRepository.save(nuevoEmpleado);
            
            respuesta.put("success", true);
            respuesta.put("mensaje", "Usuario registrado exitosamente");
            respuesta.put("usuario", username);
            
            return ResponseEntity.ok(respuesta);
            
        } catch (Exception e) {
            respuesta.put("success", false);
            respuesta.put("mensaje", "Error al registrar usuario: " + e.getMessage());
            return ResponseEntity.status(500).body(respuesta);
        }
    }
    
    /**
     * POST /api/buscar-usuario
     * Busca un usuario por nombre, cédula o teléfono
     */
    @PostMapping("/buscar-usuario")
    public ResponseEntity<UsuarioResponse> buscarUsuario(
            @RequestBody BuscarUsuarioRequest request) {
        
        try {
            // Buscar usuario en la base de datos
            Optional<Empleado> empleado = Optional.empty();
            
            // Prioridad de búsqueda: 1. Cédula, 2. Nombre, 3. Teléfono
            if (request.getCedula() != null && !request.getCedula().isEmpty()) {
                empleado = empleadoRepository.findById(request.getCedula());
            }
            
            if (!empleado.isPresent() && request.getNombre() != null && !request.getNombre().isEmpty()) {
                empleado = empleadoRepository.findByNombreContainingIgnoreCase(request.getNombre());
            }
            
            if (!empleado.isPresent() && request.getTelefono() != null && !request.getTelefono().isEmpty()) {
                empleado = empleadoRepository.findByTelefono(request.getTelefono());
            }
            
            if (empleado.isPresent()) {
                UsuarioResponse.UsuarioDTO usuarioDTO = UsuarioResponse.UsuarioDTO.builder()
                        .cedula(empleado.get().getCedula())
                        .nombre(empleado.get().getNombre())
                        .apellido(empleado.get().getApellido())
                        .telefono(empleado.get().getTelefono())
                        .usuario(empleado.get().getUsuario())
                        .nivel(empleado.get().getNivel())
                        .estado(empleado.get().getEstado())
                        .build();
                
                return ResponseEntity.ok(UsuarioResponse.success(usuarioDTO));
            } else {
                return ResponseEntity.ok(UsuarioResponse.error("No se encontró ningún usuario"));
            }
            
        } catch (Exception e) {
            return ResponseEntity.status(500)
                    .body(UsuarioResponse.error("Error al buscar usuario: " + e.getMessage()));
        }
    }
    
    /**
     * DELETE /api/eliminar-usuario/{cedula}
     * Elimina un usuario por cédula
     */
    @DeleteMapping("/eliminar-usuario/{cedula}")
    public ResponseEntity<Map<String, Object>> eliminarUsuario(
            @PathVariable String cedula,
            @RequestBody Map<String, String> request) {
        
        Map<String, Object> respuesta = new HashMap<>();
        
        try {
            // Verificar contraseña (simple para ejemplo)
            String contrasena = request.get("contrasena");
            if (!"admin123".equals(contrasena)) { // Cambia esto por tu lógica real
                respuesta.put("success", false);
                respuesta.put("mensaje", "Contraseña incorrecta");
                return ResponseEntity.status(401).body(respuesta);
            }
            
            // Verificar si el usuario existe
            Optional<Empleado> empleado = empleadoRepository.findById(cedula);
            if (!empleado.isPresent()) {
                respuesta.put("success", false);
                respuesta.put("mensaje", "Usuario no encontrado");
                return ResponseEntity.status(404).body(respuesta);
            }
            
            // Eliminar el usuario
            empleadoRepository.deleteById(cedula);
            
            respuesta.put("success", true);
            respuesta.put("mensaje", "Usuario eliminado exitosamente");
            return ResponseEntity.ok(respuesta);
            
        } catch (Exception e) {
            respuesta.put("success", false);
            respuesta.put("mensaje", "Error al eliminar usuario: " + e.getMessage());
            return ResponseEntity.status(500).body(respuesta);
        }
    }
    
    private String generarCedula() {
        Random random = new Random();
        StringBuilder cedula = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            cedula.append(random.nextInt(10));
        }
        return cedula.toString();
    }
    
    private String extraerNombre(String username) {
        if (username == null || username.isEmpty()) {
            return "Usuario";
        }
        return username.substring(0, 1).toUpperCase() + 
               (username.length() > 1 ? username.substring(1) : "");
    }

    // En RegistroController.java, añade estos métodos:

/**
 * POST /api/login
 * Autentica un usuario
 */
/**
 * POST /api/login
 * Autentica un usuario
 */
@PostMapping("/login")
public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest request, HttpSession session) {
    // <-- Añadir HttpSession como parámetro
    
    try {
        // Buscar usuario por nombre de usuario
        Optional<Empleado> empleadoOpt = empleadoRepository.findByUsuario(request.getUsername());
        
        if (!empleadoOpt.isPresent()) {
            return ResponseEntity.ok(LoginResponse.error("Usuario no encontrado"));
        }
        
        Empleado empleado = empleadoOpt.get();
        
        // Verificar credenciales
        if (!empleado.verificarCredenciales(request.getUsername(), request.getPassword())) {
            return ResponseEntity.ok(LoginResponse.error("Credenciales incorrectas"));
        }
        
        // Verificar estado del usuario
        if (empleado.getEstado() != 1) {
            return ResponseEntity.ok(LoginResponse.error("Usuario inactivo"));
        }
        
        // Crear información del usuario para la respuesta
        LoginResponse.UsuarioInfo usuarioInfo = LoginResponse.UsuarioInfo.builder()
                .cedula(empleado.getCedula())
                .nombre(empleado.getNombre())
                .apellido(empleado.getApellido())
                .usuario(empleado.getUsuario())
                .nivel(empleado.getNivel())
                .build();
        
        // **ESTABLECER LA SESIÓN DEL USUARIO** <-- Esto es lo que faltaba
        session.setAttribute("usuario", usuarioInfo);
        session.setAttribute("autenticado", true);
        session.setMaxInactiveInterval(30 * 60); // 30 minutos de inactividad
        
        return ResponseEntity.ok(LoginResponse.success(usuarioInfo));
        
    } catch (Exception e) {
        return ResponseEntity.status(500)
                .body(LoginResponse.error("Error en el servidor: " + e.getMessage()));
    }
}

/**
 * GET /api/verificar-sesion
 * Verifica si hay una sesión activa
 */
@GetMapping("/verificar-sesion")
public ResponseEntity<Map<String, Object>> verificarSesion(HttpSession session) {
    Map<String, Object> respuesta = new HashMap<>();
    
    if (session.getAttribute("usuario") != null) {
        respuesta.put("autenticado", true);
        respuesta.put("usuario", session.getAttribute("usuario"));
    } else {
        respuesta.put("autenticado", false);
    }
    
    return ResponseEntity.ok(respuesta);
}




}
package com.parking.proyecto.repository;

import org.springframework.stereotype.Repository;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import lombok.RequiredArgsConstructor;

import com.parking.proyecto.dto.RegistroActivoDTO;
import com.parking.proyecto.dto.InfoCobroResponse;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

@Repository
@RequiredArgsConstructor
public class ParqueaderoRepository {
    
    private final JdbcTemplate jdbcTemplate;
    
    /**
     * Invoca fn_registrar_vehiculo() para registrar entrada de vehículo
     */
    public Long registrarVehiculo(
            String placa,
            Integer tipoVehiculo,
            Integer tipoServicio,
            String cedula,
            String nombre,
            String apellido,
            String telefono,
            String empleado) {
        
        String sql = "SELECT * FROM fn_registrar_vehiculo(?, ?, ?, ?, ?, ?, ?, ?)";
        
        try {
            Map<String, Object> result = jdbcTemplate.queryForMap(sql,
                    placa, tipoVehiculo, tipoServicio,
                    cedula, nombre, apellido, telefono, empleado);
            
            if (result != null && result.containsKey("id_registro")) {
                String idRegistro = (String) result.get("id_registro");
                // Convertir "REG0000001" a número
                return Long.parseLong(idRegistro.replaceAll("[^0-9]", ""));
            }
            return null;
        } catch (Exception e) {
            System.err.println("Error al registrar vehículo: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Invoca fn_obtener_info_cobro() para obtener información de cobro
     * ✅ CORREGIDO: Ahora maneja correctamente la respuesta
     */
    public InfoCobroResponse obtenerInfoCobro(String placa) {
        String sql = "SELECT * FROM fn_obtener_info_cobro(?)";
        
        try {
            Map<String, Object> result = jdbcTemplate.queryForMap(sql, placa);
            
            // Verificar si la función retornó success = false
            Boolean success = (Boolean) result.get("success");
            if (success != null && !success) {
                return InfoCobroResponse.builder()
                        .success(false)
                        .mensaje((String) result.get("mensaje"))
                        .build();
            }
            
            // Construir la respuesta exitosa
            // Convertir el registro_id a String (viene como "REG0000006")
            String registroId = (String) result.get("registro_id");
            
            // Convertir fecha_entrada y hora_entrada a LocalDateTime
            LocalDate fechaEntrada = ((java.sql.Date) result.get("fecha_entrada")).toLocalDate();
            LocalTime horaEntrada = ((java.sql.Time) result.get("hora_entrada")).toLocalTime();
            LocalDateTime fechaHoraEntrada = LocalDateTime.of(fechaEntrada, horaEntrada);
            
            // Formatear tiempo_transcurrido (viene como intervalo PostgreSQL)
            String tiempoTranscurrido = result.get("tiempo_transcurrido").toString();
            
            return InfoCobroResponse.builder()
                    .success(true)
                    .mensaje((String) result.get("mensaje"))
                    .placa((String) result.get("placa"))
                    .tipoVehiculo((String) result.get("tipo_vehiculo"))
                    .tipoServicio((String) result.get("tipo_servicio"))
                    .cedula((String) result.get("cedula"))
                    .nombre((String) result.get("nombre"))
                    .telefono((String) result.get("telefono"))
                    .registroId(registroId)  // ✅ Ahora es String, no Long
                    .fechaEntrada(fechaHoraEntrada)
                    .horaEntrada(horaEntrada.toString())
                    .tiempoTranscurrido(tiempoTranscurrido)
                    .montoACobrar(new BigDecimal(result.get("monto_a_cobrar").toString()))
                    .estado("PENDIENTE")
                    .build();
            
        } catch (Exception e) {
            System.err.println("Error al obtener info de cobro: " + e.getMessage());
            e.printStackTrace();
            return InfoCobroResponse.builder()
                    .success(false)
                    .mensaje("Error técnico: " + e.getMessage())
                    .build();
        }
    }
    
    /**
     * Invoca fn_cobrar_cliente() para procesar el cobro y cerrar el registro
     * ✅ CORREGIDO: Recibe placa, no registroId
     */
    public Map<String, Object> cobrarCliente(String placa, BigDecimal monto, String empleado) {
        String sql = "SELECT * FROM fn_cobrar_cliente(?, ?, ?)";
        
        try {
            return jdbcTemplate.queryForMap(sql, placa, monto, empleado);
        } catch (Exception e) {
            System.err.println("Error al cobrar cliente: " + e.getMessage());
            e.printStackTrace();
            return Map.of(
                "success", false,
                "mensaje", "Error técnico: " + e.getMessage()
            );
        }
    }
    
    /**
     * Obtiene registros activos usando la vista v_registros_activos
     */
    public List<RegistroActivoDTO> obtenerRegistrosActivos() {
        String sql = "SELECT * FROM v_registros_activos ORDER BY fecha_entrada DESC, hora_entrada DESC";
        
        return jdbcTemplate.query(sql, new RowMapper<RegistroActivoDTO>() {
            @Override
            public RegistroActivoDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
                return RegistroActivoDTO.builder()
                        .pkcodsRegistro(rs.getLong("pkcods_registro"))
                        .fkplacaVehiculo(rs.getString("fkplaca_vehiculo"))
                        .tipoVehiculo(rs.getString("tipo_vehiculo"))
                        .tipoServicio(rs.getString("tipo_servicio"))
                        .fechaEntrada(rs.getDate("fecha_entrada").toLocalDate())
                        .horaEntrada(rs.getTime("hora_entrada").toLocalTime())
                        .nombreCliente(rs.getString("nombre_cliente"))
                        .cedulaCliente(rs.getString("cedula_cliente"))
                        .telefonoCliente(rs.getString("telefono_cliente"))
                        .empleadoRegistro(rs.getString("empleado_registro"))
                        .estado(rs.getString("estado"))
                        .build();
            }
        });
    }
    
    /**
     * Consulta la vista v_historial_completo para obtener registros del día
     * ✅ CAMBIADO: Ahora usa v_historial_completo en lugar de v_historial_dia
     */
    public List<Map<String, Object>> obtenerHistorialDia() {
        String sql = "SELECT * FROM v_historial_completo WHERE fecha_entrada = CURRENT_DATE ORDER BY hora_salida DESC NULLS LAST, hora_entrada DESC";
        
        return jdbcTemplate.queryForList(sql);
    }
    
    /**
     * Obtiene el total de ingresos del día usando ftotal_recaudado_dia()
     */
    public BigDecimal obtenerIngresosDia() {
        String sql = "SELECT ftotal_recaudado_dia(CURRENT_DATE)";
        
        try {
            return jdbcTemplate.queryForObject(sql, BigDecimal.class);
        } catch (Exception e) {
            System.err.println("Error al obtener ingresos: " + e.getMessage());
            return BigDecimal.ZERO;
        }
    }
    
    /**
     * Obtiene todas las tarifas disponibles
     */
    public List<Map<String, Object>> obtenerTarifas() {
        String sql = """
            SELECT 
                t.pkid_tarifa,
                t.fkid_tipo_vehiculo,
                tv.detalle_tipo_vehiculo as tipo_vehiculo,
                t.fkcod_tipo_servicio,
                ts.detalle_tipo_servicio as tipo_servicio,
                t.fkcod_tiempo,
                tm.tiempo_minutos,
                t.valor_tarifa
            FROM tm_tarifa t
            JOIN tm_tipo_vehiculo tv ON t.fkid_tipo_vehiculo = tv.pkid_tipo_vehiculo
            JOIN tm_tipo_servicio ts ON t.fkcod_tipo_servicio = ts.pkcod_tipo_servicio
            JOIN tm_tiempo tm ON t.fkcod_tiempo = tm.pkcod_tiempo
            WHERE t.fkcods_tarifa = 1
            ORDER BY tv.detalle_tipo_vehiculo, ts.detalle_tipo_servicio
            """;
        
        return jdbcTemplate.queryForList(sql);
    }
    
    /**
     * Método adicional: Verifica si existe la vista v_registros_activos
     * ✅ NUEVO: Para diagnóstico
     */
    public boolean existeVistaRegistrosActivos() {
        String sql = "SELECT EXISTS (SELECT 1 FROM pg_views WHERE viewname = 'v_registros_activos')";
        return jdbcTemplate.queryForObject(sql, Boolean.class);
    }
    
    /**
     * Método adicional: Obtiene definición de vista
     * ✅ NUEVO: Para diagnóstico
     */
    public String obtenerDefinicionVista(String nombreVista) {
        try {
            String sql = "SELECT definition FROM pg_views WHERE viewname = ?";
            return jdbcTemplate.queryForObject(sql, String.class, nombreVista);
        } catch (Exception e) {
            return "Vista no encontrada: " + e.getMessage();
        }
    }
}
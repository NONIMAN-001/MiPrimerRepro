package com.parking.proyecto.dto;

import lombok.Data;

@Data
public class BuscarUsuarioRequest {
    private String nombre;
    private String cedula;
    private String telefono;
}
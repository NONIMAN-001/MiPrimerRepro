package com.parking.proyecto.dto;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Builder;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InfoCobroResponse {
    
    private boolean success;
    private String mensaje;
    
    // Datos del vehículo
    private String placa;
    private String tipoVehiculo;
    private String tipoServicio;
    
    // Datos del cliente
    private String cedula;
    private String nombre;
    private String telefono;
    
    // Datos del registro - ✅ CAMBIADO A String
    private String registroId;  // ← "REG0000006"
    private LocalDateTime fechaEntrada;
    private String horaEntrada;
    
    // Cálculos
    private String tiempoTranscurrido;
    private BigDecimal montoACobrar;
    private String estado;
    
    // Factory method para errores
    public static InfoCobroResponse error(String mensaje) {
        return InfoCobroResponse.builder()
                .success(false)
                .mensaje(mensaje)
                .build();
    }
}
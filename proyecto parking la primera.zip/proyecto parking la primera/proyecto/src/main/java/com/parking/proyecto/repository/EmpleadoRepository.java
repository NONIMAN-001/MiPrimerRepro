package com.parking.proyecto.repository;

import com.parking.proyecto.models.Empleado;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface EmpleadoRepository extends JpaRepository<Empleado, String> {
    
    Optional<Empleado> findByUsuario(String usuario);
    
    Optional<Empleado> findByUsuarioAndClave(String usuario, String clave);
    
    boolean existsByUsuario(String usuario);
    
    // Añade estos métodos para búsqueda
    Optional<Empleado> findByTelefono(String telefono);
    
    @Query("SELECT e FROM Empleado e WHERE LOWER(e.nombre) LIKE LOWER(CONCAT('%', :nombre, '%'))")
    Optional<Empleado> findByNombreContainingIgnoreCase(String nombre);
}
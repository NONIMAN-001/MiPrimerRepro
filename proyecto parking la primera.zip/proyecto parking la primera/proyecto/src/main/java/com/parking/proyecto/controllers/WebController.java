package com.parking.proyecto.controllers;

import com.parking.proyecto.dto.*;
import com.parking.proyecto.service.ParqueaderoService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Map;
import java.util.HashMap;

@Controller
@RequiredArgsConstructor
public class WebController {
    
    private final ParqueaderoService parqueaderoService;
    
    // ============================================
    // RUTAS GET - Mostrar páginas
    // ============================================
    
    @GetMapping("/")
    public String index(HttpSession session) {
        // Si ya está logueado, redirigir al home
        if (session.getAttribute("usuario") != null) {
            return "redirect:/home";
        }
        return "Index";
    }
    
    @GetMapping("/home")
    public String home(Model model, HttpSession session) {
        // Verificar si el usuario está logueado
        if (session.getAttribute("usuario") == null) {
            return "redirect:/";
        }
        
        try {
            var registrosActivos = parqueaderoService.obtenerRegistrosActivos();
            Map<String, Object> ingresos = parqueaderoService.obtenerIngresosDia();
            
            model.addAttribute("registrosActivos", registrosActivos);
            model.addAttribute("totalIngresos", ingresos.get("totalIngresos"));
            model.addAttribute("cantidadCarros", ingresos.get("cantidadCarros"));
            model.addAttribute("cantidadMotos", ingresos.get("cantidadMotos"));
            model.addAttribute("usuario", session.getAttribute("usuario"));
        } catch (Exception e) {
            model.addAttribute("error", "Error al cargar datos: " + e.getMessage());
        }
        return "home";
    }
    
    @GetMapping("/index")
    public String loginPage(HttpSession session) {
        if (session.getAttribute("usuario") != null) {
            return "redirect:/home";
        }
        return "Index";
    }
    
    @GetMapping("/login")
    public String login(HttpSession session) {
        if (session.getAttribute("usuario") != null) {
            return "redirect:/home";
        }
        return "Index";
    }
    
    @GetMapping("/cobrar-cliente")
    public String cobrarCliente(Model model, HttpSession session) {
        // Verificar sesión
        if (session.getAttribute("usuario") == null) {
            return "redirect:/";
        }
        
        try {
            var registrosActivos = parqueaderoService.obtenerRegistrosActivos();
            model.addAttribute("registrosActivos", registrosActivos);
            model.addAttribute("usuario", session.getAttribute("usuario"));
        } catch (Exception e) {
            model.addAttribute("error", "Error al cargar registros: " + e.getMessage());
        }
        return "cobrarCliente";
    }
    
    @GetMapping("/cuentas")
    public String cuentas(Model model, HttpSession session) {
        // Verificar sesión
        if (session.getAttribute("usuario") == null) {
            return "redirect:/";
        }
        
        try {
            var historial = parqueaderoService.obtenerHistorialDia();
            Map<String, Object> ingresos = parqueaderoService.obtenerIngresosDia();
            
            model.addAttribute("historial", historial);
            model.addAttribute("ingresos", ingresos);
            model.addAttribute("usuario", session.getAttribute("usuario"));
        } catch (Exception e) {
            model.addAttribute("error", "Error al cargar cuentas: " + e.getMessage());
        }
        return "cuentas";
    }
    
    @GetMapping("/registrar")
    public String registrar(HttpSession session) {
        // Verificar sesión - solo administradores pueden registrar
        if (session.getAttribute("usuario") == null) {
            return "redirect:/";
        }
        return "registrar";
    }
    
    @GetMapping("/registrar-vehiculo")
    public String registrarVehiculo(Model model, HttpSession session) {
        // Verificar sesión
        if (session.getAttribute("usuario") == null) {
            return "redirect:/";
        }
        
        model.addAttribute("registro", new RegistroVehiculoRequest());
        model.addAttribute("usuario", session.getAttribute("usuario"));
        return "registrarVehiculo";
    }
    
    @GetMapping("/registros")
    public String mostrarRegistros(
            @RequestParam(required = false) String tipoRegistro,
            @RequestParam(required = false) String accion,
            Model model,
            HttpSession session) {
        
        // Verificar sesión
        if (session.getAttribute("usuario") == null) {
            return "redirect:/";
        }
        
        try {
            // 1. Cargar registros activos
            var registrosActivos = parqueaderoService.obtenerRegistrosActivos();
            model.addAttribute("registros", registrosActivos);
            
            // 2. Cargar ingresos del día
            Map<String, Object> ingresos = parqueaderoService.obtenerIngresosDia();
            model.addAttribute("totalIngresos", ingresos.get("totalIngresos"));
            model.addAttribute("cantidadCarros", ingresos.get("cantidadCarros"));
            model.addAttribute("cantidadMotos", ingresos.get("cantidadMotos"));
            model.addAttribute("usuario", session.getAttribute("usuario"));
            
            // 3. Si se selecciona "Ver Registros" (historial)
            if ("ver".equals(accion)) {
                List<Map<String, Object>> historial = parqueaderoService.obtenerHistorialDia();
                model.addAttribute("historial", historial);
                model.addAttribute("mostrarTabla", true);
            }
            
            // 4. Mantener valores seleccionados
            model.addAttribute("tipoRegistroSeleccionado", tipoRegistro);
            model.addAttribute("accionSeleccionada", accion);
            
        } catch (Exception e) {
            model.addAttribute("error", "Error al cargar datos: " + e.getMessage());
        }
        
        return "registros";
    }
    
    /**
     * Mostrar página de tarifas con datos actuales
     */
    @GetMapping("/tarifas")
    public String tarifas(Model model, HttpSession session) {
        // Verificar sesión
        if (session.getAttribute("usuario") == null) {
            return "redirect:/";
        }
        
        try {
            // Obtener las tarifas actuales para mostrar en la vista
            Map<String, Object> tarifasActuales = parqueaderoService.obtenerTarifasActuales();
            model.addAttribute("tarifas", tarifasActuales);
            model.addAttribute("usuario", session.getAttribute("usuario"));
        } catch (Exception e) {
            model.addAttribute("error", "Error al cargar tarifas: " + e.getMessage());
        }
        return "tarifas";
    }
    
    /**
     * Cerrar sesión
     */
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }
    
    // ============================================
    // RUTAS POST - Procesar formularios
    // ============================================
    
    /**
     * Procesar el registro de un vehículo desde el formulario
     */
    @PostMapping("/registrar-vehiculo")
    public String procesarRegistroVehiculo(
            @ModelAttribute RegistroVehiculoRequest request,
            RedirectAttributes redirectAttributes,
            HttpSession session) {
        
        // Verificar sesión
        if (session.getAttribute("usuario") == null) {
            return "redirect:/";
        }
        
        try {
            Map<String, Object> resultado = parqueaderoService.registrarVehiculo(request);
            
            if (resultado.containsKey("success") && (Boolean) resultado.get("success")) {
                redirectAttributes.addFlashAttribute("mensaje", "Vehículo registrado exitosamente");
                redirectAttributes.addFlashAttribute("tipo", "success");
                redirectAttributes.addFlashAttribute("registroId", resultado.get("registroId"));
            } else {
                redirectAttributes.addFlashAttribute("mensaje", resultado.get("mensaje"));
                redirectAttributes.addFlashAttribute("tipo", "error");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("mensaje", "Error al registrar: " + e.getMessage());
            redirectAttributes.addFlashAttribute("tipo", "error");
        }
        
        return "redirect:/registrar-vehiculo";
    }
    
    /**
     * Buscar información de un vehículo para cobrar
     */
    @PostMapping("/buscar-vehiculo")
    public String buscarVehiculo(
            @RequestParam("placa") String placa,
            Model model,
            RedirectAttributes redirectAttributes,
            HttpSession session) {
        
        // Verificar sesión
        if (session.getAttribute("usuario") == null) {
            return "redirect:/";
        }
        
        try {
            InfoCobroResponse info = parqueaderoService.obtenerInfoCobro(placa);
            
            if (info != null && info.isSuccess()) {
                model.addAttribute("infoVehiculo", info);
                model.addAttribute("placa", placa);
                
                // También cargar lista de registros activos
                var registrosActivos = parqueaderoService.obtenerRegistrosActivos();
                model.addAttribute("registrosActivos", registrosActivos);
                model.addAttribute("usuario", session.getAttribute("usuario"));
                
                return "cobrarCliente";
            } else {
                redirectAttributes.addFlashAttribute("mensaje", 
                    info != null ? info.getMensaje() : "No se encontró el vehículo");
                redirectAttributes.addFlashAttribute("tipo", "warning");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("mensaje", "Error al buscar: " + e.getMessage());
            redirectAttributes.addFlashAttribute("tipo", "error");
        }
        
        return "redirect:/cobrar-cliente";
    }
    
    /**
     * Procesar el cobro y salida del vehículo
     */
    @PostMapping("/cobrar-cliente")
    public String procesarCobro(
            @ModelAttribute CobrarClienteRequest request,
            RedirectAttributes redirectAttributes,
            HttpSession session) {
        
        // Verificar sesión
        if (session.getAttribute("usuario") == null) {
            return "redirect:/";
        }
        
        try {
            Map<String, Object> resultado = parqueaderoService.cobrarCliente(request);
            
            if (resultado.containsKey("success") && (Boolean) resultado.get("success")) {
                redirectAttributes.addFlashAttribute("mensaje", "Cobro procesado exitosamente");
                redirectAttributes.addFlashAttribute("tipo", "success");
                redirectAttributes.addFlashAttribute("montoFinal", resultado.get("montoFinal"));
            } else {
                redirectAttributes.addFlashAttribute("mensaje", resultado.get("mensaje"));
                redirectAttributes.addFlashAttribute("tipo", "error");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("mensaje", "Error al procesar cobro: " + e.getMessage());
            redirectAttributes.addFlashAttribute("tipo", "error");
        }
        
        return "redirect:/cobrar-cliente";
    }
    
    /**
     * Endpoint para obtener info de cobro vía AJAX
     */
    @GetMapping("/info-cobro/{placa}")
    @ResponseBody
    public InfoCobroResponse obtenerInfoCobroAjax(@PathVariable String placa, HttpSession session) {
        // Verificar sesión
        if (session.getAttribute("usuario") == null) {
            return InfoCobroResponse.error("No autenticado");
        }
        
        try {
            return parqueaderoService.obtenerInfoCobro(placa);
        } catch (Exception e) {
            return InfoCobroResponse.error("Error: " + e.getMessage());
        }
    }
    
    /**
     * Endpoint para actualizar tarifas (llamado desde AJAX)
     */
    @PostMapping("/tarifas/actualizar")
    @ResponseBody
    public Map<String, Object> actualizarTarifa(@RequestBody TarifaRequest request, HttpSession session) {
        Map<String, Object> respuesta = new HashMap<>();
        
        // Verificar sesión
        if (session.getAttribute("usuario") == null) {
            respuesta.put("success", false);
            respuesta.put("mensaje", "No autenticado");
            return respuesta;
        }
        
        try {
            // Verificar contraseña
            boolean autorizado = parqueaderoService.verificarContrasena(request.getContrasena());
            
            if (!autorizado) {
                respuesta.put("success", false);
                respuesta.put("mensaje", "Contraseña incorrecta");
                return respuesta;
            }
            
            // Actualizar tarifa
            Map<String, Object> resultado = parqueaderoService.actualizarTarifa(request);
            respuesta.put("success", resultado.get("success"));
            respuesta.put("mensaje", resultado.get("mensaje"));
            
        } catch (Exception e) {
            respuesta.put("success", false);
            respuesta.put("mensaje", "Error: " + e.getMessage());
        }
        
        return respuesta;
    }
}
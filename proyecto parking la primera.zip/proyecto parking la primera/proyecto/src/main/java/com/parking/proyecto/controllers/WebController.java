package com.parking.proyecto.controllers;

import com.parking.proyecto.dto.*;
import com.parking.proyecto.service.ParqueaderoService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;


@Controller
@RequiredArgsConstructor
public class WebController {
    
    private final ParqueaderoService parqueaderoService;
    
    // ============================================
    // RUTAS GET - Mostrar páginas
    // ============================================
    
    @GetMapping("/")
    public String index() {
        return "Index";
    }
    
        @GetMapping("/home")
        public String home(Model model) {
            try {
                var registrosActivos = parqueaderoService.obtenerRegistrosActivos();
                Map<String, Object> ingresos = parqueaderoService.obtenerIngresosDia();
                
                model.addAttribute("registrosActivos", registrosActivos);
                model.addAttribute("totalIngresos", ingresos.get("totalIngresos"));
                model.addAttribute("cantidadCarros", ingresos.get("cantidadCarros"));
                model.addAttribute("cantidadMotos", ingresos.get("cantidadMotos"));
            } catch (Exception e) {
                model.addAttribute("error", "Error al cargar datos: " + e.getMessage());
            }
            return "home";
        }
    
    @GetMapping("/index")
    public String loginPage() {
        return "Index";
    }
    
    @GetMapping("/login")
    public String login() {
        return "Index";
    }
    
    @GetMapping("/cobrar-cliente")
    public String cobrarCliente(Model model) {
        try {
            var registrosActivos = parqueaderoService.obtenerRegistrosActivos();
            model.addAttribute("registrosActivos", registrosActivos);
        } catch (Exception e) {
            model.addAttribute("error", "Error al cargar registros: " + e.getMessage());
        }
        return "cobrarCliente";
    }
    
    @GetMapping("/cuentas")
    public String cuentas(Model model) {
        try {
            var historial = parqueaderoService.obtenerHistorialDia();
            Map<String, Object> ingresos = parqueaderoService.obtenerIngresosDia();
            
            model.addAttribute("historial", historial);
            model.addAttribute("ingresos", ingresos);
        } catch (Exception e) {
            model.addAttribute("error", "Error al cargar cuentas: " + e.getMessage());
        }
        return "cuentas";
    }
    
    @GetMapping("/registrar")
    public String registrar() {
        return "registrar";
    }
    
    @GetMapping("/registrar-vehiculo")
    public String registrarVehiculo(Model model) {
        model.addAttribute("registro", new RegistroVehiculoRequest());
        return "registrarVehiculo";
    }
    
    @GetMapping("/registros")
    public String mostrarRegistros(
            @RequestParam(required = false) String tipoRegistro,
            @RequestParam(required = false) String accion,
            Model model) {
        
        try {
            // 1. Cargar registros activos (del primer método)
            var registrosActivos = parqueaderoService.obtenerRegistrosActivos();
            model.addAttribute("registros", registrosActivos);
            
            // 2. Cargar ingresos del día (del segundo método)
            Map<String, Object> ingresos = parqueaderoService.obtenerIngresosDia();
            model.addAttribute("totalIngresos", ingresos.get("totalIngresos"));
            model.addAttribute("cantidadCarros", ingresos.get("cantidadCarros"));
            model.addAttribute("cantidadMotos", ingresos.get("cantidadMotos"));
            
            // 3. Si se selecciona "Ver Registros" (historial)
            if ("ver".equals(accion)) {
                List<Map<String, Object>> historial = parqueaderoService.obtenerHistorialDia();
                model.addAttribute("historial", historial);
                model.addAttribute("mostrarTabla", true);
            }
            
            // 4. Mantener valores seleccionados
            model.addAttribute("tipoRegistroSeleccionado", tipoRegistro);
            model.addAttribute("accionSeleccionada", accion);
            
        } catch (Exception e) {
            model.addAttribute("error", "Error al cargar datos: " + e.getMessage());
        }
        
        return "registros";
    }
    
    @GetMapping("/tarifas")
    public String tarifas() {
        return "tarifas";
    }
    
    // ============================================
    // RUTAS POST - Procesar formularios
    // ============================================
    
    /**
     * Procesar el registro de un vehículo desde el formulario
     */
    @PostMapping("/registrar-vehiculo")
    public String procesarRegistroVehiculo(
            @ModelAttribute RegistroVehiculoRequest request,
            RedirectAttributes redirectAttributes
    ) {
        try {
            Map<String, Object> resultado = parqueaderoService.registrarVehiculo(request);
            
            if (resultado.containsKey("success") && (Boolean) resultado.get("success")) {
                redirectAttributes.addFlashAttribute("mensaje", "Vehículo registrado exitosamente");
                redirectAttributes.addFlashAttribute("tipo", "success");
                redirectAttributes.addFlashAttribute("registroId", resultado.get("registroId"));
            } else {
                redirectAttributes.addFlashAttribute("mensaje", resultado.get("mensaje"));
                redirectAttributes.addFlashAttribute("tipo", "error");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("mensaje", "Error al registrar: " + e.getMessage());
            redirectAttributes.addFlashAttribute("tipo", "error");
        }
        
        return "redirect:/registrar-vehiculo";
    }
    
    /**
     * Buscar información de un vehículo para cobrar
     */
    @PostMapping("/buscar-vehiculo")
    public String buscarVehiculo(
            @RequestParam("placa") String placa,
            Model model,
            RedirectAttributes redirectAttributes
    ) {
        try {
            InfoCobroResponse info = parqueaderoService.obtenerInfoCobro(placa);
            
            if (info != null && info.isSuccess()) {
                model.addAttribute("infoVehiculo", info);
                model.addAttribute("placa", placa);
                
                // También cargar lista de registros activos
                var registrosActivos = parqueaderoService.obtenerRegistrosActivos();
                model.addAttribute("registrosActivos", registrosActivos);
                
                return "cobrarCliente";
            } else {
                redirectAttributes.addFlashAttribute("mensaje", 
                    info != null ? info.getMensaje() : "No se encontró el vehículo");
                redirectAttributes.addFlashAttribute("tipo", "warning");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("mensaje", "Error al buscar: " + e.getMessage());
            redirectAttributes.addFlashAttribute("tipo", "error");
        }
        
        return "redirect:/cobrar-cliente";
    }
    
    /**
     * Procesar el cobro y salida del vehículo
     */
    @PostMapping("/cobrar-cliente")
    public String procesarCobro(
            @ModelAttribute CobrarClienteRequest request,
            RedirectAttributes redirectAttributes
    ) {
        try {
            Map<String, Object> resultado = parqueaderoService.cobrarCliente(request);
            
            if (resultado.containsKey("success") && (Boolean) resultado.get("success")) {
                redirectAttributes.addFlashAttribute("mensaje", "Cobro procesado exitosamente");
                redirectAttributes.addFlashAttribute("tipo", "success");
                redirectAttributes.addFlashAttribute("montoFinal", resultado.get("montoFinal"));
            } else {
                redirectAttributes.addFlashAttribute("mensaje", resultado.get("mensaje"));
                redirectAttributes.addFlashAttribute("tipo", "error");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("mensaje", "Error al procesar cobro: " + e.getMessage());
            redirectAttributes.addFlashAttribute("tipo", "error");
        }
        
        return "redirect:/cobrar-cliente";
    }
    
    /**
     * Endpoint para obtener info de cobro vía AJAX (si tu HTML lo usa)
     */
    @GetMapping("/info-cobro/{placa}")
    @ResponseBody
    public InfoCobroResponse obtenerInfoCobroAjax(@PathVariable String placa) {
        try {
            return parqueaderoService.obtenerInfoCobro(placa);
        } catch (Exception e) {
            return InfoCobroResponse.error("Error: " + e.getMessage());
        }
    }

}
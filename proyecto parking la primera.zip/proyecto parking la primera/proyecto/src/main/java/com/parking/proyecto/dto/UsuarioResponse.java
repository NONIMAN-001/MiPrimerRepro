package com.parking.proyecto.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UsuarioResponse {
    private boolean success;
    private String mensaje;
    private UsuarioDTO usuario;
    
    @Data
    @Builder
    public static class UsuarioDTO {
        private String cedula;
        private String nombre;
        private String apellido;
        private String telefono;
        private String usuario;
        private Integer nivel;
        private Integer estado;
    }
    
    public static UsuarioResponse success(UsuarioDTO usuario) {
        return UsuarioResponse.builder()
                .success(true)
                .mensaje("Usuario encontrado")
                .usuario(usuario)
                .build();
    }
    
    public static UsuarioResponse error(String mensaje) {
        return UsuarioResponse.builder()
                .success(false)
                .mensaje(mensaje)
                .usuario(null)
                .build();
    }
}
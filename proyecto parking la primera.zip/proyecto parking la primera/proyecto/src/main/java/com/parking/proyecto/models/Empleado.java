package com.parking.proyecto.models;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "tm_empleado")
@Data
public class Empleado {
    
    @Id
    @Column(name = "pkc_empleado", length = 12)
    private String cedula;
    
    @Column(name = "nombre_empleado", nullable = false, length = 50)
    private String nombre;
    
    @Column(name = "apellido_empleado", nullable = false, length = 50)
    private String apellido;
    
    @Column(name = "telefono_empleado", nullable = false, length = 15)
    private String telefono;
    
    @Column(name = "usuario_empleado", nullable = false, length = 20)
    private String usuario;
    
    @Column(name = "clave_empleado", nullable = false, length = 15)
    private String clave;
    
    @Column(name = "nivel_empleado", nullable = false)
    private Integer nivel;
    
    @Column(name = "fkcods_empleado", nullable = false)
    private Integer estado = 1;
    
    // Método para verificar credenciales
    public boolean verificarCredenciales(String username, String password) {
        return this.usuario.equals(username) && this.clave.equals(password) && this.estado == 1;
    }
}
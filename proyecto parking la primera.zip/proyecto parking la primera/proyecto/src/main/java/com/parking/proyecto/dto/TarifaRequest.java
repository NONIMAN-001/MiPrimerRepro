package com.parking.proyecto.dto;

import lombok.Data;

@Data
public class TarifaRequest {
    private String tipoVehiculo; // "carro" o "moto"
    private String tipoTiempo; // "fraccion", "dia", "media-mensualidad", "mes"
    
    // Para tarifas simples (dia, media-mensualidad, mes)
    private Double valor;
    
    // Para fracciones
    private Double valor15min;
    private Double valor30min;
    private Double valor45min;
    private Double valor1hora;
    
    // AÑADE ESTE CAMPO para la contraseña
    private String contrasena;
}
package com.parking.proyecto.service;

import com.parking.proyecto.dto.*;
import com.parking.proyecto.repository.ParqueaderoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

@Service
@RequiredArgsConstructor
public class ParqueaderoService {
    
    private final ParqueaderoRepository repository;
    
    /**
     * Registra la entrada de un vehículo al parqueadero
     */
    @Transactional
    public Map<String, Object> registrarVehiculo(RegistroVehiculoRequest request) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            if (request.getPlaca() == null || request.getPlaca().trim().isEmpty()) {
                response.put("success", false);
                response.put("mensaje", "La placa es obligatoria");
                return response;
            }
            
            if (request.getTipoVehiculo() == null) {
                response.put("success", false);
                response.put("mensaje", "El tipo de vehículo es obligatorio");
                return response;
            }
            
            if (request.getTipoServicio() == null) {
                response.put("success", false);
                response.put("mensaje", "El tipo de servicio es obligatorio");
                return response;
            }
            
            Long registroId = repository.registrarVehiculo(
                request.getPlaca().toUpperCase(),
                request.getTipoVehiculo(),
                request.getTipoServicio(),
                request.getCedula(),
                request.getNombre(),
                request.getApellido(),
                request.getTelefono(),
                request.getEmpleado() != null ? request.getEmpleado() : "1234567890"
            );
            
            if (registroId != null && registroId > 0) {
                response.put("success", true);
                response.put("mensaje", "Vehículo registrado exitosamente");
                response.put("registroId", registroId);
            } else {
                response.put("success", false);
                response.put("mensaje", "No se pudo registrar el vehículo. Verifique que no exista un registro activo.");
            }
            
        } catch (Exception e) {
            response.put("success", false);
            response.put("mensaje", "Error al registrar: " + e.getMessage());
        }
        
        return response;
    }
    
    /**
     * Obtiene información de un vehículo para realizar el cobro
     */
    public InfoCobroResponse obtenerInfoCobro(String placa) {
        try {
            if (placa == null || placa.trim().isEmpty()) {
                return InfoCobroResponse.error("La placa es requerida");
            }
            
            InfoCobroResponse info = repository.obtenerInfoCobro(placa.toUpperCase());
            
            if (info == null) {
                return InfoCobroResponse.error("No se encontró registro activo para la placa: " + placa);
            }
            
            return info;
                
        } catch (Exception e) {
            return InfoCobroResponse.error("Error al obtener información: " + e.getMessage());
        }
    }
    
    /**
     * Procesa el cobro y cierra el registro del vehículo
     */
    @Transactional
    public Map<String, Object> cobrarCliente(CobrarClienteRequest request) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            if (!request.esValido()) {
                response.put("success", false);
                response.put("mensaje", "Datos incompletos para procesar el cobro");
                return response;
            }
            
            Map<String, Object> resultado = repository.cobrarCliente(
                request.getPlaca(),
                request.getMonto(),
                request.getEmpleado() != null ? request.getEmpleado() : "1234567890"
            );
            
            if (resultado != null && resultado.containsKey("success") && 
                (Boolean) resultado.get("success")) {
                response.put("success", true);
                response.put("mensaje", "Cobro procesado exitosamente");
                response.put("montoFinal", resultado.get("monto_final"));
                response.put("registroId", resultado.get("registro_id"));
            } else {
                response.put("success", false);
                response.put("mensaje", resultado != null ? resultado.get("mensaje") : "No se pudo procesar el cobro");
            }
            
        } catch (Exception e) {
            response.put("success", false);
            response.put("mensaje", "Error al procesar cobro: " + e.getMessage());
        }
        
        return response;
    }
    
    /**
     * Obtiene la lista de registros activos (vehículos dentro del parqueadero)
     */
    public List<RegistroActivoDTO> obtenerRegistrosActivos() {
        try {
            return repository.obtenerRegistrosActivos();
        } catch (Exception e) {
            System.err.println("Error al obtener registros activos: " + e.getMessage());
            return new ArrayList<>();
        }
    }
    
    /**
     * Obtiene el historial de registros del día
     */
    public List<Map<String, Object>> obtenerHistorialDia() {
        try {
            return repository.obtenerHistorialDia();
        } catch (Exception e) {
            System.err.println("Error al obtener historial: " + e.getMessage());
            return new ArrayList<>();
        }
    }
    
    /**
     * Obtiene los ingresos del día con estadísticas
     */
    public Map<String, Object> obtenerIngresosDia() {
        Map<String, Object> resultado = new HashMap<>();
        
        try {
            BigDecimal totalIngresos = repository.obtenerIngresosDia();
            List<Map<String, Object>> historial = repository.obtenerHistorialDia();
            
            int cantidadCarros = 0;
            int cantidadMotos = 0;
            
            for (Map<String, Object> registro : historial) {
                String tipoVehiculo = (String) registro.get("tipo_vehiculo");
                if (tipoVehiculo != null) {
                    if ("Carro".equalsIgnoreCase(tipoVehiculo)) {
                        cantidadCarros++;
                    } else if ("Moto".equalsIgnoreCase(tipoVehiculo)) {
                        cantidadMotos++;
                    }
                }
            }
            
            resultado.put("totalIngresos", totalIngresos != null ? totalIngresos : BigDecimal.ZERO);
            resultado.put("cantidadCarros", cantidadCarros);
            resultado.put("cantidadMotos", cantidadMotos);
            resultado.put("cantidadTotal", cantidadCarros + cantidadMotos);
            resultado.put("fecha", LocalDate.now());
            
        } catch (Exception e) {
            resultado.put("totalIngresos", BigDecimal.ZERO);
            resultado.put("cantidadCarros", 0);
            resultado.put("cantidadMotos", 0);
            resultado.put("cantidadTotal", 0);
            resultado.put("error", e.getMessage());
        }
        
        return resultado;
    }
    
    /**
     * Obtiene las tarifas disponibles
     */
    public List<Map<String, Object>> obtenerTarifasDisponibles() {
        try {
            return repository.obtenerTarifas();
        } catch (Exception e) {
            System.err.println("Error al obtener tarifas: " + e.getMessage());
            return new ArrayList<>();
        }
    }
    
    // ============================================
    // MÉTODOS PARA TARIFAS
    // ============================================
    
    /**
     * Obtiene las tarifas actuales desde la base de datos
     */
    public Map<String, Object> obtenerTarifasActuales() {
        Map<String, Object> tarifas = new HashMap<>();
        
        try {
            List<Map<String, Object>> tarifasDB = repository.obtenerTarifas();
            
            // Organizar las tarifas por tipo de vehículo
            Map<String, List<Map<String, Object>>> tarifasPorVehiculo = new HashMap<>();
            
            for (Map<String, Object> tarifa : tarifasDB) {
                String tipoVehiculo = (String) tarifa.get("tipo_vehiculo");
                if (tipoVehiculo != null) {
                    tarifasPorVehiculo.computeIfAbsent(tipoVehiculo.toLowerCase(), k -> new ArrayList<>()).add(tarifa);
                }
            }
            
            tarifas.put("carro", tarifasPorVehiculo.getOrDefault("carro", new ArrayList<>()));
            tarifas.put("moto", tarifasPorVehiculo.getOrDefault("moto", new ArrayList<>()));
            
        } catch (Exception e) {
            tarifas.put("carro", new ArrayList<>());
            tarifas.put("moto", new ArrayList<>());
            tarifas.put("error", "Error al obtener tarifas: " + e.getMessage());
        }
        
        return tarifas;
    }
    
    /**
     * Verifica la contraseña para actualizar tarifas
     */
    public boolean verificarContrasena(String contrasena) {
        // Contraseña temporal - cambiar por una más segura en producción
        String contrasenaCorrecta = "admin123";
        return contrasenaCorrecta != null && contrasenaCorrecta.equals(contrasena);
    }
    
    /**
     * Actualiza una tarifa en la base de datos
     */
    @Transactional
    public Map<String, Object> actualizarTarifa(TarifaRequest request) {
        Map<String, Object> resultado = new HashMap<>();
        
        try {
            // Validar datos requeridos
            if (request.getTipoVehiculo() == null || request.getTipoVehiculo().isEmpty()) {
                resultado.put("success", false);
                resultado.put("mensaje", "El tipo de vehículo es requerido");
                return resultado;
            }
            
            if (request.getTipoTiempo() == null || request.getTipoTiempo().isEmpty()) {
                resultado.put("success", false);
                resultado.put("mensaje", "El tipo de tiempo es requerido");
                return resultado;
            }
            
            // Llamar al repository para actualizar la tarifa
            int filasActualizadas = repository.actualizarTarifa(
                request.getTipoVehiculo(),
                request.getTipoTiempo(),
                request.getValor(),
                request.getValor15min(),
                request.getValor30min(),
                request.getValor45min(),
                request.getValor1hora()
            );
            
            if (filasActualizadas > 0) {
                resultado.put("success", true);
                resultado.put("mensaje", "Tarifa actualizada exitosamente");
                resultado.put("filasActualizadas", filasActualizadas);
            } else {
                resultado.put("success", false);
                resultado.put("mensaje", "No se pudo actualizar la tarifa. Verifica los datos.");
            }
            
        } catch (Exception e) {
            resultado.put("success", false);
            resultado.put("mensaje", "Error al actualizar tarifa: " + e.getMessage());
        }
        
        return resultado;
    }
    
    // ============================================
    // MÉTODOS AUXILIARES
    // ============================================
}
package com.parking.proyecto.service;

import com.parking.proyecto.dto.*;
import com.parking.proyecto.repository.ParqueaderoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

@Service
@RequiredArgsConstructor
public class ParqueaderoService {
    
    private final ParqueaderoRepository repository;
    
    /**
     * Registra la entrada de un vehículo al parqueadero
     */
    @Transactional
    public Map<String, Object> registrarVehiculo(RegistroVehiculoRequest request) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            if (request.getPlaca() == null || request.getPlaca().trim().isEmpty()) {
                response.put("success", false);
                response.put("mensaje", "La placa es obligatoria");
                return response;
            }
            
            if (request.getTipoVehiculo() == null) {
                response.put("success", false);
                response.put("mensaje", "El tipo de vehículo es obligatorio");
                return response;
            }
            
            if (request.getTipoServicio() == null) {
                response.put("success", false);
                response.put("mensaje", "El tipo de servicio es obligatorio");
                return response;
            }
            
            Long registroId = repository.registrarVehiculo(
                request.getPlaca().toUpperCase(),
                request.getTipoVehiculo(),
                request.getTipoServicio(),
                request.getCedula(),
                request.getNombre(),
                request.getApellido(),
                request.getTelefono(),
                request.getEmpleado() != null ? request.getEmpleado() : "1234567890"
            );
            
            if (registroId != null && registroId > 0) {
                response.put("success", true);
                response.put("mensaje", "Vehículo registrado exitosamente");
                response.put("registroId", registroId);
            } else {
                response.put("success", false);
                response.put("mensaje", "No se pudo registrar el vehículo. Verifique que no exista un registro activo.");
            }
            
        } catch (Exception e) {
            response.put("success", false);
            response.put("mensaje", "Error al registrar: " + e.getMessage());
        }
        
        return response;
    }
    
    /**
     * Obtiene información de un vehículo para realizar el cobro
     */
    public InfoCobroResponse obtenerInfoCobro(String placa) {
        try {
            if (placa == null || placa.trim().isEmpty()) {
                return InfoCobroResponse.error("La placa es requerida");
            }
            
            InfoCobroResponse info = repository.obtenerInfoCobro(placa.toUpperCase());
            
            if (info == null) {
                return InfoCobroResponse.error("No se encontró registro activo para la placa: " + placa);
            }
            
            return info;
                
        } catch (Exception e) {
            return InfoCobroResponse.error("Error al obtener información: " + e.getMessage());
        }
    }
    
    /**
     * Procesa el cobro y cierra el registro del vehículo
     */
    @Transactional
    public Map<String, Object> cobrarCliente(CobrarClienteRequest request) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            if (!request.esValido()) {
                response.put("success", false);
                response.put("mensaje", "Datos incompletos para procesar el cobro");
                return response;
            }
            
            Map<String, Object> resultado = repository.cobrarCliente(
                request.getPlaca(),
                request.getMonto(),
                request.getEmpleado() != null ? request.getEmpleado() : "1234567890"
            );
            
            if (resultado != null && resultado.containsKey("success") && 
                (Boolean) resultado.get("success")) {
                response.put("success", true);
                response.put("mensaje", "Cobro procesado exitosamente");
                response.put("montoFinal", resultado.get("monto_final"));
                response.put("registroId", resultado.get("registro_id"));
            } else {
                response.put("success", false);
                response.put("mensaje", resultado != null ? resultado.get("mensaje") : "No se pudo procesar el cobro");
            }
            
        } catch (Exception e) {
            response.put("success", false);
            response.put("mensaje", "Error al procesar cobro: " + e.getMessage());
        }
        
        return response;
    }
    
    /**
     * Obtiene la lista de registros activos (vehículos dentro del parqueadero)
     */
    public List<RegistroActivoDTO> obtenerRegistrosActivos() {
        try {
            return repository.obtenerRegistrosActivos();
        } catch (Exception e) {
            System.err.println("Error al obtener registros activos: " + e.getMessage());
            return new ArrayList<>();
        }
    }
    
    /**
     * Obtiene el historial de registros del día
     */
    public List<Map<String, Object>> obtenerHistorialDia() {
        try {
            return repository.obtenerHistorialDia();
        } catch (Exception e) {
            System.err.println("Error al obtener historial: " + e.getMessage());
            return new ArrayList<>();
        }
    }
    
    /**
     * Obtiene los ingresos del día con estadísticas
     */
    public Map<String, Object> obtenerIngresosDia() {
        Map<String, Object> resultado = new HashMap<>();
        
        try {
            // Obtener datos usando métodos del repository
            BigDecimal totalIngresos = repository.obtenerIngresosDia();
            List<Map<String, Object>> historial = repository.obtenerHistorialDia();
            
            int cantidadCarros = 0;
            int cantidadMotos = 0;
            
            for (Map<String, Object> registro : historial) {
                String tipoVehiculo = (String) registro.get("tipo_vehiculo");
                if (tipoVehiculo != null) {
                    if ("Carro".equalsIgnoreCase(tipoVehiculo)) {
                        cantidadCarros++;
                    } else if ("Moto".equalsIgnoreCase(tipoVehiculo)) {
                        cantidadMotos++;
                    }
                }
            }
            
            resultado.put("totalIngresos", totalIngresos != null ? totalIngresos : BigDecimal.ZERO);
            resultado.put("cantidadCarros", cantidadCarros);
            resultado.put("cantidadMotos", cantidadMotos);
            resultado.put("cantidadTotal", cantidadCarros + cantidadMotos);
            resultado.put("fecha", LocalDate.now());
            
        } catch (Exception e) {
            resultado.put("totalIngresos", BigDecimal.ZERO);
            resultado.put("cantidadCarros", 0);
            resultado.put("cantidadMotos", 0);
            resultado.put("cantidadTotal", 0);
            resultado.put("error", e.getMessage());
        }
        
        return resultado;
    }
    
    /**
     * Obtiene las tarifas disponibles - ✅ AÑADIDO
     */
    public List<Map<String, Object>> obtenerTarifasDisponibles() {
        try {
            return repository.obtenerTarifas();
        } catch (Exception e) {
            System.err.println("Error al obtener tarifas: " + e.getMessage());
            return new ArrayList<>();
        }
    }
    
    // ============================================
    // MÉTODOS AUXILIARES
    // ============================================
    
    private BigDecimal getBigDecimal(Object value) {
        if (value == null) return BigDecimal.ZERO;
        if (value instanceof BigDecimal) return (BigDecimal) value;
        if (value instanceof Double) return BigDecimal.valueOf((Double) value);
        if (value instanceof Integer) return BigDecimal.valueOf((Integer) value);
        if (value instanceof String) {
            try {
                return new BigDecimal((String) value);
            } catch (Exception e) {
                return BigDecimal.ZERO;
            }
        }
        return BigDecimal.ZERO;
    }
}
package com.parking.proyecto.dto;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;

/**
 * DTO para procesar el cobro al cliente
 * Compatible con cobrarCliente.html form submit
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CobrarClienteRequest {
    
    private String placa;
    private BigDecimal monto;
    
    // Datos del cliente (solo para referencia)
    private String cedula;
    private String nombre;
    private String telefono;
    
    // Empleado que realiza el cobro (se obtiene de la sesión)
    private String empleado;
    
    /**
     * Valida que los datos obligatorios estén presentes
     */
    public boolean esValido() {
        return placa != null && !placa.trim().isEmpty() &&
               monto != null && monto.compareTo(BigDecimal.ZERO) > 0;
    }
}
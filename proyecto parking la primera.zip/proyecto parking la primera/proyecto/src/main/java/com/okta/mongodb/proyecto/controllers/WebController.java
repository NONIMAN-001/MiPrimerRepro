package com.okta.mongodb.proyecto.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class WebController {
    
    @GetMapping("/")
    public String index() {
        return "Index";
    }
    
    @GetMapping("/home")
    public String home() {
        return "home";
    }
    
    @GetMapping("/index")
    public String loginPage() {
        return "Index";
    }
    
    @GetMapping("/login")
    public String login() {
        return "Index";
    }
    
    @GetMapping("/cobrar-cliente")
    public String cobrarCliente() {
        return "cobrarCliente";
    }
    
    @GetMapping("/cuentas")
    public String cuentas() {
        return "cuentas";
    }
    
    @GetMapping("/registrar")
    public String registrar() {
        return "registrar";
    }
    
    @GetMapping("/registrar-vehiculo")
    public String registrarVehiculo() {
        return "registrarVehiculo";
    }
    
    @GetMapping("/registros")
    public String registros() {
        return "registros";
    }
    
    @GetMapping("/tarifas")
    public String tarifas() {
        return "tarifas";
    }
}
// fecha-hora.js
function actualizarFecha() {
    const diasSemana = ["domingo", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado"];
    const hoy = new Date();
    const diaSemana = diasSemana[hoy.getDay()];
    const dia = hoy.getDate().toString().padStart(2, '0');
    const mes = (hoy.getMonth() + 1).toString().padStart(2, '0');
    const año = hoy.getFullYear();
    const fecha = `${diaSemana} ${dia}/${mes}/${año}`;
    document.getElementById('fecha-actual').textContent = fecha;
}

function actualizarHora() {
    const ahora = new Date();
    const hora12 = ahora.toLocaleTimeString('es-ES', {
        hour: 'numeric',
        minute: '2-digit',
        second: '2-digit',
        hour12: true
    });
    document.getElementById('hora-actual').textContent = hora12;
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', function() {
    actualizarFecha();
    actualizarHora();
    setInterval(actualizarHora, 1000);
    setInterval(actualizarFecha, 60000);
});S
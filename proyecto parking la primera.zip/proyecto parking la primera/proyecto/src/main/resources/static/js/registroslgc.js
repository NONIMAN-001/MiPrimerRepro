    
    /*ciro si lees esto adelante esta parte para que ajustes lo demas*/
    <script>
        document.getElementById('registrosForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const tipoRegistro = document.getElementById('tipoRegistro').value;
            const accion = document.getElementById('accion').value;
            
            if (!tipoRegistro || !accion) {
                alert('Por favor seleccione todas las opciones');
                return;
            }
            
            // Simulación de acciones
            if (accion === 'imprimir') {
                alert(`Generando PDF de registros: ${tipoRegistro}`);


                // Aquí iría la lógica para generar PDF



            } else if (accion === 'ver') {


                mostrarRegistros(tipoRegistro);



            } else if (accion === 'vaciar') {
                
                if (confirm(`¿Está seguro de vaciar la tabla de ${tipoRegistro}?`)) {
                    alert('Tabla vaciada correctamente');
                    document.getElementById('resultados-container').style.display = 'none';
                }
            }
        });
        
        function mostrarRegistros(tipo) {

        }
    </script>
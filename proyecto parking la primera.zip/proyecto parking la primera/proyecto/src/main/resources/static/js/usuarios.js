document.addEventListener('DOMContentLoaded', function() {
    // Elementos del DOM
    const btnBuscar = document.getElementById('btn-buscar');
    const btnRegistrarse = document.getElementById('boton-registrarse');
    const btnEliminar = document.getElementById('btn-eliminar');
    const inputNombre = document.getElementById('input-nombre');
    const inputCedula = document.getElementById('input-cedula');
    const inputTelefono = document.getElementById('input-telefono');
    const datosUsuario = document.getElementById('datos-usuario');
    const sinResultados = document.getElementById('sin-resultados');
    
    // Elementos para mostrar datos
    const mostrarNombre = document.getElementById('mostrar-nombre');
    const mostrarCedula = document.getElementById('mostrar-cedula');
    const mostrarTelefono = document.getElementById('mostrar-telefono');
    
    // Modal de contraseña (eliminar)
    const modalContrasena = document.getElementById('modal-contrasena');
    const inputContrasena = document.getElementById('input-contrasena');
    const btnConfirmarContrasena = document.getElementById('btn-confirmar-contrasena');
    const btnCancelarContrasena = document.getElementById('btn-cancelar-contrasena');
    const mensajeError = document.getElementById('mensaje-error');
    
    // Modal de registrar
    const modalRegistrar = document.getElementById('modal-registrar');
    const inputContrasenaAdmin = document.getElementById('input-contrasena-admin');
    const btnConfirmarRegistrar = document.getElementById('btn-confirmar-registrar');
    const btnCancelarRegistrar = document.getElementById('btn-cancelar-registrar');
    const mensajeErrorRegistrar = document.getElementById('mensaje-error-registrar');
    
    // Variable para almacenar el usuario actual
    let usuarioActual = null;
    
    // ============================================
    // FUNCIÓN PARA BUSCAR USUARIO
    // ============================================
    function buscarUsuario() {
        const datosBusqueda = {
            nombre: inputNombre.value.trim(),
            cedula: inputCedula.value.trim(),
            telefono: inputTelefono.value.trim()
        };
        
        // Validar que al menos un campo tenga valor
        if (!datosBusqueda.nombre && !datosBusqueda.cedula && !datosBusqueda.telefono) {
            alert('Por favor ingresa al menos un criterio de búsqueda');
            return;
        }
        
        // Mostrar indicador de carga
        btnBuscar.disabled = true;
        btnBuscar.textContent = 'Buscando...';
        
        // Enviar solicitud al backend
        fetch('/api/buscar-usuario', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(datosBusqueda)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Error en la respuesta del servidor');
            }
            return response.json();
        })
        .then(resultado => {
            btnBuscar.disabled = false;
            btnBuscar.textContent = 'Buscar';
            
            if (resultado.success && resultado.usuario) {
                // Mostrar resultados
                usuarioActual = resultado.usuario;
                mostrarDatosUsuario(resultado.usuario);
                datosUsuario.style.display = 'block';
                sinResultados.style.display = 'none';
            } else {
                // Mostrar mensaje de no encontrado
                datosUsuario.style.display = 'none';
                sinResultados.style.display = 'block';
                sinResultados.innerHTML = `<p>${resultado.mensaje}</p>`;
                usuarioActual = null;
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error al buscar usuario. Por favor, intente nuevamente.');
            btnBuscar.disabled = false;
            btnBuscar.textContent = 'Buscar';
        });
    }
    
    // ============================================
    // FUNCIÓN PARA MOSTRAR DATOS DEL USUARIO
    // ============================================
    function mostrarDatosUsuario(usuario) {
        mostrarNombre.textContent = usuario.nombre + ' ' + usuario.apellido;
        mostrarCedula.textContent = usuario.cedula;
        mostrarTelefono.textContent = usuario.telefono;
    }
    
    // ============================================
    // FUNCIÓN PARA ELIMINAR USUARIO
    // ============================================
    function eliminarUsuario() {
        if (!usuarioActual) {
            alert('No hay usuario seleccionado para eliminar');
            return;
        }
        
        // Mostrar modal para confirmar contraseña
        inputContrasena.value = '';
        mensajeError.style.display = 'none';
        modalContrasena.style.display = 'flex';
    }
    
    // ============================================
    // FUNCIÓN PARA CONFIRMAR ELIMINACIÓN
    // ============================================
    function confirmarEliminacion() {
        const contrasena = inputContrasena.value.trim();
        
        if (!contrasena) {
            alert('Por favor ingresa la contraseña');
            return;
        }
        
        // Enviar solicitud para eliminar
        fetch(`/api/eliminar-usuario/${usuarioActual.cedula}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ contrasena: contrasena })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Error en la respuesta del servidor');
            }
            return response.json();
        })
        .then(resultado => {
            if (resultado.success) {
                alert('Usuario eliminado exitosamente');
                // Limpiar formulario y ocultar resultados
                inputNombre.value = '';
                inputCedula.value = '';
                inputTelefono.value = '';
                datosUsuario.style.display = 'none';
                sinResultados.style.display = 'block';
                sinResultados.innerHTML = '<p>No se encontraron usuarios. Realiza una búsqueda.</p>';
                usuarioActual = null;
                modalContrasena.style.display = 'none';
            } else {
                mensajeError.textContent = resultado.mensaje;
                mensajeError.style.display = 'block';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            mensajeError.textContent = 'Error al eliminar usuario';
            mensajeError.style.display = 'block';
        });
    }
    
    // ============================================
    // FUNCIÓN PARA REGISTRAR NUEVO USUARIO
    // ============================================
    function abrirRegistro() {
        inputContrasenaAdmin.value = '';
        mensajeErrorRegistrar.style.display = 'none';
        modalRegistrar.style.display = 'flex';
    }
    
    function confirmarRegistro() {
        const contrasena = inputContrasenaAdmin.value.trim();
        
        if (!contrasena) {
            alert('Por favor ingresa la contraseña de administrador');
            return;
        }
        
        // Aquí puedes añadir lógica para verificar contraseña de admin
        if (contrasena === 'admin123') { // Cambia esto por tu lógica real
            // Redirigir a la página de registro
            window.location.href = '/registrar';
        } else {
            mensajeErrorRegistrar.style.display = 'block';
        }
    }
    
    // ============================================
    // EVENT LISTENERS
    // ============================================
    
    // Buscar usuario
    if (btnBuscar) {
        btnBuscar.addEventListener('click', buscarUsuario);
        
        // También buscar al presionar Enter en cualquier campo
        [inputNombre, inputCedula, inputTelefono].forEach(input => {
            input.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    buscarUsuario();
                }
            });
        });
    }
    
    // Eliminar usuario
    if (btnEliminar) {
        btnEliminar.addEventListener('click', eliminarUsuario);
    }
    
    // Registrarse
    if (btnRegistrarse) {
        btnRegistrarse.addEventListener('click', abrirRegistro);
    }
    
    // Modal de contraseña (eliminar)
    if (btnConfirmarContrasena) {
        btnConfirmarContrasena.addEventListener('click', confirmarEliminacion);
    }
    
    if (btnCancelarContrasena) {
        btnCancelarContrasena.addEventListener('click', function() {
            modalContrasena.style.display = 'none';
        });
    }
    
    // Modal de registrar
    if (btnConfirmarRegistrar) {
        btnConfirmarRegistrar.addEventListener('click', confirmarRegistro);
    }
    
    if (btnCancelarRegistrar) {
        btnCancelarRegistrar.addEventListener('click', function() {
            modalRegistrar.style.display = 'none';
        });
    }
    
    // Cerrar modales al hacer clic fuera
    window.addEventListener('click', function(event) {
        if (event.target === modalContrasena) {
            modalContrasena.style.display = 'none';
        }
        if (event.target === modalRegistrar) {
            modalRegistrar.style.display = 'none';
        }
    });
});
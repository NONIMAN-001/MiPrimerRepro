// Mostrar fecha y hora actual
function actualizarFechaHora() {
    const ahora = new Date();
    
    const opciones = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const fecha = ahora.toLocaleDateString('es-ES', opciones);
    
    const horas = String(ahora.getHours()).padStart(2, '0');
    const minutos = String(ahora.getMinutes()).padStart(2, '0');
    const hora = `${horas}:${minutos}`;
    
    document.getElementById('fecha-actual').textContent = fecha;
    document.getElementById('hora-actual').textContent = hora;
}

actualizarFechaHora();
setInterval(actualizarFechaHora, 60000);

// Modal para Registrar Usuario
const modalRegistrar = document.getElementById('modal-registrar');
const botonRegistrarse = document.getElementById('boton-registrarse');
const btnConfirmarRegistrar = document.getElementById('btn-confirmar-registrar');
const btnCancelarRegistrar = document.getElementById('btn-cancelar-registrar');
const inputContraseñaAdmin = document.getElementById('input-contrasena-admin');
const mensajeErrorRegistrar = document.getElementById('mensaje-error-registrar');

// Contraseña de administrador (cambiar según sea necesario)
const CONTRASEÑA_ADMIN = 'admin123';

// Abrir modal de registro
if (botonRegistrarse) {
    botonRegistrarse.addEventListener('click', function() {
        modalRegistrar.style.display = 'flex';
        inputContraseñaAdmin.value = '';
        mensajeErrorRegistrar.style.display = 'none';
        inputContraseñaAdmin.focus();
    });
}

// Confirmar contraseña de administrador
if (btnConfirmarRegistrar) {
    btnConfirmarRegistrar.addEventListener('click', function() {
        if (inputContraseñaAdmin.value === CONTRASEÑA_ADMIN) {
            modalRegistrar.style.display = 'none';
            window.location.href = '/registrar';
        } else {
            mensajeErrorRegistrar.style.display = 'block';
            inputContraseñaAdmin.value = '';
            inputContraseñaAdmin.focus();
        }
    });
}

// Cancelar modal de registro
if (btnCancelarRegistrar) {
    btnCancelarRegistrar.addEventListener('click', function() {
        modalRegistrar.style.display = 'none';
        inputContraseñaAdmin.value = '';
        mensajeErrorRegistrar.style.display = 'none';
    });
}

// Cerrar modal al presionar Enter o Escape
if (modalRegistrar) {
    modalRegistrar.addEventListener('keydown', function(event) {
        if (event.key === 'Enter') {
            btnConfirmarRegistrar.click();
        } else if (event.key === 'Escape') {
            btnCancelarRegistrar.click();
        }
    });
}

// Modal para Eliminar Usuario (código existente)
const modalContrasena = document.getElementById('modal-contrasena');
const botonEliminar = document.getElementById('btn-eliminar');
const btnConfirmarContrasena = document.getElementById('btn-confirmar-contrasena');
const btnCancelarContrasena = document.getElementById('btn-cancelar-contrasena');
const inputContrasena = document.getElementById('input-contrasena');
const mensajeError = document.getElementById('mensaje-error');

// Abrir modal de eliminar usuario
if (botonEliminar) {
    botonEliminar.addEventListener('click', function() {
        modalContrasena.style.display = 'flex';
        inputContrasena.value = '';
        mensajeError.style.display = 'none';
        inputContrasena.focus();
    });
}

// Confirmar contraseña para eliminar usuario
if (btnConfirmarContrasena) {
    btnConfirmarContrasena.addEventListener('click', function() {
        // Aquí va la lógica de verificación de contraseña
        if (inputContrasena.value === CONTRASEÑA_ADMIN) {
            modalContrasena.style.display = 'none';
            // Aquí va la lógica para eliminar el usuario
            console.log('Usuario eliminado');
        } else {
            mensajeError.style.display = 'block';
            inputContrasena.value = '';
            inputContrasena.focus();
        }
    });
}

// Cancelar modal de eliminar usuario
if (btnCancelarContrasena) {
    btnCancelarContrasena.addEventListener('click', function() {
        modalContrasena.style.display = 'none';
        inputContrasena.value = '';
        mensajeError.style.display = 'none';
    });
}

// Cerrar modal de contraseña al presionar Escape o Enter
if (modalContrasena) {
    modalContrasena.addEventListener('keydown', function(event) {
        if (event.key === 'Enter') {
            btnConfirmarContrasena.click();
        } else if (event.key === 'Escape') {
            btnCancelarContrasena.click();
        }
    });
}

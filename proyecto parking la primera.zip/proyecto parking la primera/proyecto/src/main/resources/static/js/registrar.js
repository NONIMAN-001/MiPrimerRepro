document.addEventListener('DOMContentLoaded', function() {
  
  const btnCrearCuenta = document.getElementById('BT-crear-cuenta');
  const btnGoogle = document.getElementById('btn-google');
  const btnOutlook = document.getElementById('btn-outlook');

  // Validación al crear cuenta
  if (btnCrearCuenta) {
    btnCrearCuenta.addEventListener('click', function(e) {
      e.preventDefault();
      
      const username = document.querySelector('input[name="username"]').value;
      const email = document.querySelector('input[name="email"]').value;
      const phone = document.querySelector('input[name="phone"]').value;
      const password = document.querySelector('input[name="password"]').value;
      const confirmPassword = document.querySelector('input[name="confirm_password"]').value;
      
      // Validaciones
      if (!username || !email || !phone || !password || !confirmPassword) {
        alert('Por favor completa todos los campos');
        return;
      }
      
      if (password.length < 6) {
        alert('La contraseña debe tener al menos 6 caracteres');
        return;
      }
      
      if (password !== confirmPassword) {
        alert('Las contraseñas no coinciden');
        return;
      }
      
      // Mostrar indicador de carga
      btnCrearCuenta.disabled = true;
      btnCrearCuenta.textContent = 'Registrando...';
      
      // Enviar datos al backend
      const datos = {
        username: username,
        email: email,
        phone: phone,
        password: password,
        confirm_password: confirmPassword  // ¡ATENCIÓN! coincide con "confirm_password" del backend
      };
      
      fetch('/api/registrar-usuario', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(datos)
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('Error en la respuesta del servidor');
        }
        return response.json();
      })
      .then(result => {
        if (result.success) {
          alert(`¡${result.mensaje}!\nBienvenido ${username} 🎉`);
          window.location.href = '/';
        } else {
          alert('Error: ' + result.mensaje);
          btnCrearCuenta.disabled = false;
          btnCrearCuenta.textContent = 'Crear Cuenta';
        }
      })
      .catch(error => {
        console.error('Error:', error);
        alert('Error al conectar con el servidor. Por favor, intente nuevamente.');
        btnCrearCuenta.disabled = false;
        btnCrearCuenta.textContent = 'Crear Cuenta';
      });
    });
  }

  // Botón Google
  if (btnGoogle) {
    btnGoogle.addEventListener('click', function() {
      alert('🔐 Registrándote con Google... (Funcionalidad en desarrollo)');
    });
  }

  // Botón Outlook
  if (btnOutlook) {
    btnOutlook.addEventListener('click', function() {
      alert('🔐 Registrándote con Outlook... (Funcionalidad en desarrollo)');
    });
  }
});
// js/registrar.js

document.addEventListener('DOMContentLoaded', function() {
  
  const btnCrearCuenta = document.getElementById('BT-crear-cuenta');
  const btnGoogle = document.getElementById('btn-google');
  const btnOutlook = document.getElementById('btn-outlook');

  // Validación al crear cuenta
  if (btnCrearCuenta) {
    btnCrearCuenta.addEventListener('click', function(e) {
      e.preventDefault();
      
      const username = document.querySelector('input[name="username"]').value;
      const email = document.querySelector('input[name="email"]').value;
      const phone = document.querySelector('input[name="phone"]').value;
      const password = document.querySelector('input[name="password"]').value;
      const confirmPassword = document.querySelector('input[name="confirm_password"]').value;
      
      // Validaciones
      if (!username || !email || !phone || !password || !confirmPassword) {
        alert('Por favor completa todos los campos');
        return;
      }
      
      if (password.length < 6) {
        alert('La contraseña debe tener al menos 6 caracteres');
        return;
      }
      
      if (password !== confirmPassword) {
        alert('Las contraseñas no coinciden');
        return;
      }
      
      // Si todo está bien
      alert(`¡Cuenta creada exitosamente!\nBienvenido ${username} 🎉`);
      window.location.href = '../index.html';
    });
  }

  // Botón Google
  if (btnGoogle) {
    btnGoogle.addEventListener('click', function() {
      alert('🔐 Registrándote con Google... (Implementar OAuth)');
    });
  }

  // Botón Outlook
  if (btnOutlook) {
    btnOutlook.addEventListener('click', function() {
      alert('🔐 Registrándote con Outlook... (Implementar OAuth)');
    });
  }
});
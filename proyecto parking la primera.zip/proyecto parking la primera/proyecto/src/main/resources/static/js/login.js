// js/login.js

// Validación del formulario
document.addEventListener('DOMContentLoaded', function() {
  
  const btnIngresar = document.getElementById('boton-ingresar');
  const btnGoogle = document.getElementById('boton-google');
  const btnOutlook = document.getElementById('boton-outlook');
  const btnRegistrarse = document.getElementById('boton-registrarse');
  const loginForm = document.getElementById('loginForm');

  // Validación al hacer clic en INGRESAR
  if (btnIngresar) {
    btnIngresar.addEventListener('click', function(e) {
      e.preventDefault();
      
      const username = document.getElementById('input-usuario').value;
      const password = document.getElementById('input-contrasena').value;
      
      if (!username || !password) {
        alert('Por favor completa todos los campos');
        return;
      }
      
      if (password.length < 6) {
        alert('La contraseña debe tener al menos 6 caracteres');
        return;
      }
      
      // Si todo está bien, redirigir al home
      window.location.href = '/home';
    });
  }

  // Botón Google
  if (btnGoogle) {
    btnGoogle.addEventListener('click', function() {
      alert('🔐 Redirigiendo a Google... (Implementar OAuth)');
    });
  }

  // Botón Outlook
  if (btnOutlook) {
    btnOutlook.addEventListener('click', function() {
      alert('🔐 Redirigiendo a Outlook... (Implementar OAuth)');
    });
  }

  // Botón Registrarse
  if (btnRegistrarse) {
    btnRegistrarse.addEventListener('click', function(e) {
      e.preventDefault();
      window.location.href = '/registrar';
    });
  }
});

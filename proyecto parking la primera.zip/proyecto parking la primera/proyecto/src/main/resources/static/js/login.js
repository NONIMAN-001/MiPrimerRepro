document.addEventListener('DOMContentLoaded', function() {
    const btnIngresar = document.getElementById('boton-ingresar');
    const inputUsuario = document.getElementById('input-usuario');
    const inputContrasena = document.getElementById('input-contrasena');
    const btnGoogle = document.getElementById('boton-google');
    const btnOutlook = document.getElementById('boton-outlook');
    const loginForm = document.getElementById('loginForm');

    // Función para realizar el login
    function realizarLogin() {
        const username = inputUsuario.value.trim();
        const password = inputContrasena.value.trim();
        
        // Validaciones básicas
        if (!username || !password) {
            alert('Por favor completa todos los campos');
            return;
        }
        
        if (password.length < 6) {
            alert('La contraseña debe tener al menos 6 caracteres');
            return;
        }
        
        // Mostrar indicador de carga
        btnIngresar.disabled = true;
        btnIngresar.textContent = 'Ingresando...';
        
        // Enviar datos al backend
        const datosLogin = {
            username: username,
            password: password
        };
        
        fetch('/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(datosLogin)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Error en la respuesta del servidor');
            }
            return response.json();
        })
        .then(resultado => {
            if (resultado.success) {
                // Almacenar información del usuario en sessionStorage
                sessionStorage.setItem('usuario', JSON.stringify(resultado.usuario));
                sessionStorage.setItem('autenticado', 'true');
                
                // Redirigir a la página de inicio
                window.location.href = resultado.redirectUrl;
            } else {
                alert('Error: ' + resultado.mensaje);
                btnIngresar.disabled = false;
                btnIngresar.textContent = 'INGRESAR';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error al conectar con el servidor. Por favor, intente nuevamente.');
            btnIngresar.disabled = false;
            btnIngresar.textContent = 'INGRESAR';
        });
    }

    // Event listener para el botón ingresar
    if (btnIngresar) {
        btnIngresar.addEventListener('click', realizarLogin);
    }

    // Permitir login con Enter
    if (loginForm) {
        loginForm.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                realizarLogin();
            }
        });
    }

    // Botones sociales (placeholder)
    if (btnGoogle) {
        btnGoogle.addEventListener('click', function() {
            alert('🔐 Ingresando con Google... (Funcionalidad en desarrollo)');
        });
    }

    if (btnOutlook) {
        btnOutlook.addEventListener('click', function() {
            alert('🔐 Ingresando con Outlook... (Funcionalidad en desarrollo)');
        });
    }

    // Verificar si ya está autenticado
    function verificarAutenticacion() {
        fetch('/api/verificar-sesion')
            .then(response => response.json())
            .then(data => {
                if (data.autenticado) {
                    // Si ya está autenticado, redirigir al home
                    window.location.href = '/home';
                }
            })
            .catch(error => {
                console.error('Error verificando sesión:', error);
            });
    }

    // Verificar autenticación al cargar la página
    verificarAutenticacion();
});
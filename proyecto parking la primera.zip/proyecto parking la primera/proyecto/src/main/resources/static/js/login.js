// js/login.js

// Validación del formulario
document.addEventListener('DOMContentLoaded', function() {
  
  const btnIngresar = document.getElementById('BT-ingresar');
  const btnGoogle = document.getElementById('btn-google');
  const btnOutlook = document.getElementById('btn-outlook');
  const btnRegistrarse = document.getElementById('BT-registrate');

  // Validación al hacer clic en INGRESAR
  if (btnIngresar) {
    btnIngresar.addEventListener('click', function(e) {
      e.preventDefault();
      
      const username = document.getElementById('username').value;
      const password = document.getElementById('password').value;
      
      if (!username || !password) {
        alert('Por favor completa todos los campos');
        return;
      }
      
      if (password.length < 6) {
        alert('La contraseña debe tener al menos 6 caracteres');
        return;
      }
      
      // Si todo está bien, redirigir
      window.location.href = 'html/home.html';
    });
  }

  // Botón Google
  if (btnGoogle) {
    btnGoogle.addEventListener('click', function() {
      alert('🔐 Redirigiendo a Google... (Implementar OAuth)');
    });
  }

  // Botón Outlook
  if (btnOutlook) {
    btnOutlook.addEventListener('click', function() {
      alert('🔐 Redirigiendo a Outlook... (Implementar OAuth)');
    });
  }

  // Botón Registrarse
  if (btnRegistrarse) {
    btnRegistrarse.addEventListener('click', function() {
      window.location.href = 'html/registrar.html';
    });
  }
});
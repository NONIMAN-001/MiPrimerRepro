-- Script para crear la base de datos ----> bd_parking_laprimera		              
-- Autores: Juan David Bohorquez Prieto, Kevin Julian Angarita Vega, Daniel Andres Galvis Marin, Ciro Sneider Olarte Carvajal               
-------------------------------------------------------------------------
-- 01.- BLOQUE CREAR BD
SELECT 'Paso 00: Bloque Crear BD_PARKING_LAPRIMERA .....'  AS paso, pg_sleep(10);
SELECT '.........................................'  AS paso, pg_sleep(0);
-------------------------------------------------------------------------

\! cls
\c postgres
SELECT 'Paso 01.1: Iniciando el Script .....'  AS paso, pg_sleep(01);

SELECT 'Paso 01.2: Listado de las BDs .....'  AS paso, pg_sleep(02);
\l

-- Eliminando la base de datos si existe
SELECT 'Paso 01.3: Eliminar BD_parking_laprimera si Existe .....'  AS paso, pg_sleep(05);
DROP DATABASE IF EXISTS bd_parking_laprimera;

\l

\! cls
SELECT 'Paso 01.4: Crear BD_parking_laprimera .....'  AS paso, pg_sleep(05);
CREATE DATABASE bd_parking_laprimera with ENCODING='UTF8';

SELECT 'Paso 01.5: Conectandose a bd_parking_laprimera .....'  AS paso, pg_sleep(05);
\c bd_parking_laprimera

-------------------------------------------------------------------------
-- 02.- BLOQUE DE CREACIÓN DE TABLAS
SELECT 'Paso 02: Bloque Crear TABLAS .....'  AS paso, pg_sleep(10);
SELECT '.........................................'  AS paso, pg_sleep(0);
-------------------------------------------------------------------------

-- TM_ESTADO
SELECT 'Paso 02.01: TMESTADO .....................'  AS paso, pg_sleep(05);

create table tm_estado(
    pkcods integer not null primary key,
    detalle_estado varchar(20) not null
);

insert into tm_estado(pkcods,detalle_estado) values (1,'ACTIVO'),(2,'INACTIVO'),(3,'DEBE'),(4,'NO DEBE');

-- TM_TIEMPO
SELECT 'Paso 02.02: TM_TIEMPO .....................'  AS paso, pg_sleep(03);

create table tm_tiempo(
    pkcod_tiempo serial not null primary key,
    detalle_tiempo varchar(40) not null,
    tiempo_minutos integer not null,
    fkcods_tiempo integer not null,
    foreign key(fkcods_tiempo) references tm_estado(pkcods) on update cascade on delete restrict
);

insert into tm_tiempo(detalle_tiempo, tiempo_minutos, fkcods_tiempo) values
('15 minutos', 15, 1),
('30 minutos', 30, 1),
('45 minutos', 45, 1),
('1 hora', 60, 1),
('1 dia', 1440, 1),
('1 semana', 10080, 1),
('1 mes', 43200, 1),
('1 año', 525600, 1);

-- TM_TIPO_VEHICULO
SELECT 'Paso 02.03: TM_TIPO_VEHICULO .....................'  AS paso, pg_sleep(05);

create table tm_tipo_vehiculo(
    pkid_tipo_vehiculo integer not null primary key,
    detalle_tipo_vehiculo varchar(50) not null,
    fkcods_tipo_vehiculo integer not null,
    foreign key(fkcods_tipo_vehiculo) references tm_estado(pkcods) on update cascade on delete restrict
);

insert into tm_tipo_vehiculo(pkid_tipo_vehiculo,detalle_tipo_vehiculo,fkcods_tipo_vehiculo) values 
(1000, 'Carro', 1),
(2000, 'Moto', 1);

-- TM_CLIENTE
SELECT 'Paso 02.04: TM_CLIENTE .....................'  AS paso, pg_sleep(02);

create table tm_cliente(
    pkc_cliente varchar(12) not null primary key,
    nombre_cliente varchar(50) not null,
    apellido_cliente varchar(50) not null,
    telefono_cliente varchar(15) not null,
    fkcods_cliente integer not null,
    foreign key(fkcods_cliente) references tm_estado(pkcods) on update cascade on delete restrict
);

Insert into tm_cliente(pkc_cliente,nombre_cliente,apellido_cliente,telefono_cliente,fkcods_cliente) values
('1012345678', 'Juan', 'Pérez', '3004567890', 1),
('1023456789', 'María', 'Gómez', '3012345678', 1),
('1034567890', 'Carlos', 'López', '3023456781', 1),
('1045678901', 'Ana', 'Martínez', '3009876543', 1),
('1056789012', 'Luis', 'Rodríguez', '3156782345', 1),
('1067890123', 'Valentina', 'Hernández', '3167890123', 1),
('1078901234', 'Andrés', 'Ramírez', '3115678901', 1),
('1089012345', 'Diana', 'Castro', '3146789012', 1),
('1090123456', 'Miguel', 'Cárdenas', '3203456789', 1),
('1101234567', 'Laura', 'Moreno', '3134567890', 1),
('1112345678', 'Santiago', 'Torres', '3226789012', 1),
('1123456789', 'Camila', 'Ortega', '3127894561', 1),
('1134567890', 'Felipe', 'Guerrero', '3172345678', 1),
('1145678901', 'Paula', 'Rojas', '3198765432', 1),
('1156789012', 'Daniel', 'Santos', '3213456789', 1),
('1167890123', 'Isabela', 'Vargas', '3209876543', 1),
('1178901234', 'Sebastián', 'Mendoza', '3187654321', 1),
('1189012345', 'Natalia', 'Pineda', '3165432187', 1),
('1190123456', 'Oscar', 'Salazar', '3152345678', 1),
('1201234567', 'Luisa', 'Fernández', '3109876543', 1);

-- TM_TIPO_SERVICIO
SELECT 'Paso 02.05: TM_TIPO_SERVICIO .....................'  AS paso, pg_sleep(04);

create table tm_tipo_servicio(
    pkcod_tipo_servicio integer not null primary key,
    detalle_tipo_servicio varchar(30) not null,
    fkcods_tipo_servicio integer not null,
    foreign key(fkcods_tipo_servicio) references tm_estado(pkcods) on update cascade on delete restrict
);

insert into tm_tipo_servicio(pkcod_tipo_servicio,detalle_tipo_servicio, fkcods_tipo_servicio) values
(1, 'normal', 1),
(2, 'media mensualidad', 1),
(3, 'mensualidad', 1);

-- TM_EMPLEADO
SELECT 'Paso 02.06: TM_EMPLEADO .....................'  AS paso, pg_sleep(03);

create table tm_empleado(
    pkc_empleado varchar(12) not null primary key,
    nombre_empleado varchar(50) not null,
    apellido_empleado varchar(50) not null,
    telefono_empleado varchar(15) not null,
    usuario_empleado varchar(20) not null,
    clave_empleado varchar(15) not null,
    nivel_empleado integer not null,
    fkcods_empleado integer not null,
    foreign key(fkcods_empleado) references tm_estado(pkcods) on update cascade on delete restrict
);

Insert into tm_empleado(pkc_empleado,nombre_empleado,apellido_empleado,telefono_empleado,usuario_empleado,clave_empleado,nivel_empleado,fkcods_empleado) values
('1234567890','Jair','Angarita Bustos','3123456781','noniman','admin123',1,1),
('1234567891','Kevin Julian','Angarita Vega','3100000002','overgame','pass123',2,1);

-- TM_VEHICULO
SELECT 'Paso 02.07: TM_VEHICULO .....................'  AS paso, pg_sleep(05);

create table tm_vehiculo(
    pkplaca_vehiculo varchar(20) not null primary key,
    detalle_vehiculo varchar(30) not null,
    fkid_tipo_vehiculo integer not null,
    fkc_cliente varchar(12),
    fkcods_vehiculo integer not null,
    foreign key(fkid_tipo_vehiculo) references tm_tipo_vehiculo(pkid_tipo_vehiculo) on update cascade on delete restrict,
    foreign key(fkc_cliente) references tm_cliente(pkc_cliente) on update cascade on delete restrict,
    foreign key(fkcods_vehiculo) references tm_estado(pkcods) on update cascade on delete restrict
);

Insert into tm_vehiculo(pkplaca_vehiculo,detalle_vehiculo,fkid_tipo_vehiculo,fkc_cliente,fkcods_vehiculo) values
('ABC123', 'Toyota Corolla', 1000, '1012345678', 1),
('DEF456', 'Honda Civic', 1000, '1023456789', 1),
('GHI789', 'Ford Fiesta', 1000, '1034567890', 1),
('JKL234', 'Chevrolet Spark', 1000, '1045678901', 1),
('MNO567', 'Nissan Versa', 1000, '1056789012', 1),
('PQR890', 'Volkswagen Gol', 1000, '1067890123', 1),
('STU345', 'Hyundai i10', 1000, '1078901234', 1),
('VWX678', 'Kia Picanto', 1000, '1089012345', 1),
('YZA901', 'Mazda 3', 1000, '1090123456', 1),
('BCD234', 'BMW Serie 1', 1000, '1101234567', 1),
('EFG12A', 'Honda CB125F', 2000, '1112345678', 1),
('HIJ34B', 'Yamaha FZ 2.0', 2000, '1123456789', 1),
('KLM56C', 'Kawasaki Z250', 2000, '1134567890', 1),
('NOP78D', 'Suzuki Gixxer', 2000, '1145678901', 1),
('QRS90E', 'KTM Duke 200', 2000, '1156789012', 1),
('TUV12F', 'Ducati Monster 797', 2000, '1167890123', 1),
('WXY34G', 'Harley Street 750', 2000, '1178901234', 1),
('ZAB56H', 'Triumph Street Twin', 2000, '1189012345', 1),
('CDE78I', 'Royal Enfield Classic 350', 2000, '1190123456', 1),
('FGH90J', 'Bajaj Pulsar NS200', 2000, '1201234567', 1);

-- TM_TARIFA
SELECT 'Paso 02.08: TM_TARIFA .....................'  AS paso, pg_sleep(03);

create table tm_tarifa(
    pkid_tarifa varchar(10) not null primary key,
    detalle_tarifa varchar(30) not null,
    valor_tarifa decimal(15,2) not null,
    fkcod_tipo_servicio integer not null,
    fkid_tipo_vehiculo integer not null,
    fkcod_tiempo integer not null,
    fkcods_tarifa integer not null,
    foreign key(fkcod_tipo_servicio) references tm_tipo_servicio(pkcod_tipo_servicio) on update cascade on delete restrict,
    foreign key(fkid_tipo_vehiculo) references tm_tipo_vehiculo(pkid_tipo_vehiculo) on update cascade on delete restrict,
    foreign key(fkcod_tiempo) references tm_tiempo(pkcod_tiempo) on update cascade on delete restrict,
    foreign key(fkcods_tarifa) references tm_estado(pkcods) on update cascade on delete restrict
);

insert into tm_tarifa(pkid_tarifa,detalle_tarifa,valor_tarifa,fkcod_tipo_servicio,fkid_tipo_vehiculo,fkcod_tiempo,fkcods_tarifa) values
('TAR101', 'Carro 15 min', 1200, 1, 1000, 1, 1),
('TAR102', 'Carro 30 min', 2000, 1, 1000, 2, 1),
('TAR103', 'Carro 45 min', 3200, 1, 1000, 3, 1),
('TAR104', 'Carro 1 hora', 4000, 1, 1000, 4, 1),
('TAR105', 'Carro media mensualidad', 70000, 2, 1000, 7, 1),
('TAR106', 'Carro mensualidad', 140000, 3, 1000, 7, 1),
('TAR201', 'Moto 15 min', 900, 1, 2000, 1, 1),
('TAR202', 'Moto 30 min', 1000, 1, 2000, 2, 1),
('TAR203', 'Moto 45 min', 1200, 1, 2000, 3, 1),
('TAR204', 'Moto 1 hora', 1300, 1, 2000, 4, 1),
('TAR205', 'Moto media mensualidad', 35000, 2, 2000, 7, 1),
('TAR206', 'Moto mensualidad', 70000, 3, 2000, 7, 1);

-- TD_PAGOS
SELECT 'Paso 02.09: TD_PAGOS .....................'  AS paso, pg_sleep(04);

create table td_pagos(
    pkid_pago varchar(10) not null primary key,
    fecha_pago date not null,
    monto_pagado decimal(15,2) not null,
    fkc_cliente varchar(12) not null,
    fkcods_pagos integer not null,
    foreign key(fkc_cliente) references tm_cliente(pkc_cliente) on update cascade on delete restrict,
    foreign key(fkcods_pagos) references tm_estado(pkcods) on update cascade on delete restrict
);

insert into td_pagos(pkid_pago,fecha_pago,monto_pagado,fkc_cliente,fkcods_pagos) values
('PAG001', CURRENT_DATE, 4000, '1012345678', 1),
('PAG002', CURRENT_DATE, 2000, '1023456789', 1),
('PAG003', CURRENT_DATE, 6000, '1034567890', 1),
('PAG004', CURRENT_DATE, 8000, '1045678901', 1),
('PAG005', CURRENT_DATE, 1200, '1056789012', 1);

-- TD_REGISTROS
SELECT 'Paso 02.10: TD_REGISTROS .....................'  AS paso, pg_sleep(05);

create table td_registros(
    pkid_registro varchar(10) not null primary key,
    fecha_entrada date not null,
    hora_entrada time,
    fecha_salida date,
    hora_salida time,
    fkplaca_vehiculo varchar(20) not null,
    fkid_pago varchar(20),
    fkc_empleado varchar(12),
    fkid_tarifa varchar(10),
    fkcod_tipo_servicio integer,
    fkcods_registro integer not null,
    foreign key(fkplaca_vehiculo) references tm_vehiculo(pkplaca_vehiculo) on update cascade on delete restrict,
    foreign key(fkid_pago) references td_pagos(pkid_pago) on update cascade on delete restrict,
    foreign key(fkc_empleado) references tm_empleado(pkc_empleado) on update cascade on delete restrict,
    foreign key(fkid_tarifa) references tm_tarifa(pkid_tarifa) on update cascade on delete restrict,
    foreign key(fkcod_tipo_servicio) references tm_tipo_servicio(pkcod_tipo_servicio) on update cascade on delete restrict,
    foreign key(fkcods_registro) references tm_estado(pkcods) on update cascade on delete restrict
);

insert into td_registros(pkid_registro,fecha_entrada,hora_entrada,fecha_salida,hora_salida,fkplaca_vehiculo,fkid_pago,fkc_empleado,fkid_tarifa,fkcod_tipo_servicio,fkcods_registro) values
('REG001', CURRENT_DATE, '08:00:00', NULL, NULL, 'ABC123', 'PAG001', '1234567890', 'TAR104', 1, 1),
('REG002', CURRENT_DATE, '09:30:00', NULL, NULL, 'DEF456', 'PAG002', '1234567890', 'TAR102', 1, 1),
('REG003', CURRENT_DATE, '07:45:00', NULL, NULL, 'GHI789', 'PAG003', '1234567890', 'TAR104', 1, 1),
('REG004', CURRENT_DATE, '12:15:00', NULL, NULL, 'JKL234', 'PAG004', '1234567890', 'TAR106', 3, 1),
('REG005', CURRENT_DATE, '14:00:00', NULL, NULL, 'MNO567', 'PAG005', '1234567890', 'TAR101', 1, 1);

-------------------------------------------------------------------------
-- 03.- FUNCIONES
SELECT 'Paso 03: Bloque Crear FUNCIONES .....'  AS paso, pg_sleep(10);
SELECT '.........................................'  AS paso, pg_sleep(0);
-------------------------------------------------------------------------

-- Funcion para calcular el total recaudado en un dia
SELECT 'Paso 03.01: Funcion ftotal_recaudado_dia .....................'  AS paso, pg_sleep(03);

CREATE OR REPLACE FUNCTION ftotal_recaudado_dia(xfecha date)
RETURNS numeric(15,2) AS $$
DECLARE
    total_monto numeric(15,2);
BEGIN
    total_monto := (SELECT SUM(monto_pagado) 
    FROM td_pagos
    WHERE fecha_pago = xfecha);

    IF total_monto IS NULL THEN
        total_monto := 0;
    END IF;

    RETURN total_monto;
END;
$$ LANGUAGE plpgsql;

-- Funcion para calcular la tarifa segun el tiempo de estadia
SELECT 'Paso 03.02: Funcion fcalcular_tarifa .....................'  AS paso, pg_sleep(03);

CREATE OR REPLACE FUNCTION fcalcular_tarifa(
    xfecha_entrada date,
    xhora_entrada time,
    xfecha_salida date,
    xhora_salida time,
    xtipo_vehiculo integer,
    xtipo_servicio integer
) RETURNS numeric(15,2) AS $$
DECLARE
    v_duracion_minutos integer;
    v_horas_completas integer;
    v_minutos_restantes integer;
    v_tiempo_fraccion_cobrar integer;
    v_tarifa_hora numeric(15,2);
    v_tarifa_fraccion numeric(15,2);
    v_tarifa_total numeric(15,2);
    v_margen_anticipacion integer;
BEGIN
    v_tarifa_total := 0;
    v_margen_anticipacion := 3;

    v_duracion_minutos := EXTRACT(EPOCH FROM ((xfecha_salida + xhora_salida)::timestamp - (xfecha_entrada + xhora_entrada)::timestamp)) / 60;

    IF v_duracion_minutos < 0 THEN
        v_duracion_minutos := 0;
    END IF;

    IF xtipo_servicio = 1 THEN
        SELECT valor_tarifa INTO v_tarifa_hora
        FROM tm_tarifa t
        JOIN tm_tiempo tm ON t.fkcod_tiempo = tm.pkcod_tiempo
        WHERE t.fkid_tipo_vehiculo = xtipo_vehiculo
          AND t.fkcod_tipo_servicio = 1
          AND tm.tiempo_minutos = 60;

        IF v_duracion_minutos <= 60 THEN
            v_duracion_minutos := v_duracion_minutos + v_margen_anticipacion;

            IF v_duracion_minutos <= 15 THEN
                v_tiempo_fraccion_cobrar := 15;
            ELSIF v_duracion_minutos <= 30 THEN
                v_tiempo_fraccion_cobrar := 30;
            ELSIF v_duracion_minutos <= 45 THEN
                v_tiempo_fraccion_cobrar := 45;
            ELSE
                v_tiempo_fraccion_cobrar := 60;
            END IF;

            SELECT valor_tarifa INTO v_tarifa_total
            FROM tm_tarifa t
            JOIN tm_tiempo tm ON t.fkcod_tiempo = tm.pkcod_tiempo
            WHERE t.fkid_tipo_vehiculo = xtipo_vehiculo
              AND t.fkcod_tipo_servicio = 1
              AND tm.tiempo_minutos = v_tiempo_fraccion_cobrar;

        ELSE
            v_horas_completas := FLOOR(v_duracion_minutos / 60);
            v_minutos_restantes := v_duracion_minutos % 60;

            v_tarifa_total := v_horas_completas * v_tarifa_hora;

            IF v_minutos_restantes > 0 THEN
                v_minutos_restantes := v_minutos_restantes + v_margen_anticipacion;

                IF v_minutos_restantes <= 15 THEN
                    v_tiempo_fraccion_cobrar := 15;
                ELSIF v_minutos_restantes <= 30 THEN
                    v_tiempo_fraccion_cobrar := 30;
                ELSIF v_minutos_restantes <= 45 THEN
                    v_tiempo_fraccion_cobrar := 45;
                ELSE
                    v_tiempo_fraccion_cobrar := 60;
                END IF;

                SELECT valor_tarifa INTO v_tarifa_fraccion
                FROM tm_tarifa t
                JOIN tm_tiempo tm ON t.fkcod_tiempo = tm.pkcod_tiempo
                WHERE t.fkid_tipo_vehiculo = xtipo_vehiculo
                  AND t.fkcod_tipo_servicio = 1
                  AND tm.tiempo_minutos = v_tiempo_fraccion_cobrar;

                v_tarifa_total := v_tarifa_total + COALESCE(v_tarifa_fraccion, 0);
            END IF;
        END IF;

    ELSE
        SELECT valor_tarifa INTO v_tarifa_total
        FROM tm_tarifa
        WHERE fkid_tipo_vehiculo = xtipo_vehiculo
          AND fkcod_tipo_servicio = xtipo_servicio
        LIMIT 1;
    END IF;

    RETURN COALESCE(v_tarifa_total, 0);
END;
$$ LANGUAGE plpgsql;

-- =========================================================================
-- FUNCIONES ADICIONALES PARA EL BACKEND SPRING BOOT
-- Agregar estas funciones después de la sección 03 (FUNCIONES) del script
-- =========================================================================

-- Función 1: Registrar entrada de vehículo
SELECT 'Paso 03.03: Función fn_registrar_vehiculo .....................'  AS paso, pg_sleep(03);

CREATE OR REPLACE FUNCTION fn_registrar_vehiculo(
    p_placa varchar,
    p_tipo_vehiculo integer,
    p_tipo_servicio integer,
    p_cedula varchar DEFAULT NULL,
    p_nombre varchar DEFAULT NULL,
    p_apellido varchar DEFAULT NULL,
    p_telefono varchar DEFAULT NULL,
    p_detalle_vehiculo varchar DEFAULT NULL,
    p_empleado varchar DEFAULT '1234567890'
) RETURNS TABLE(
    success boolean,
    mensaje text,
    id_registro varchar,
    id_pago varchar
) AS $$
DECLARE
    v_id_registro varchar(10);
    v_id_pago varchar(10);
    v_id_tarifa varchar(10);
    v_monto numeric(15,2);
    v_cliente_existe boolean;
    v_vehiculo_existe boolean;
    v_contador integer;
BEGIN
    -- Validar que no exista un registro activo para esta placa
    IF EXISTS (SELECT 1 FROM td_registros WHERE fkplaca_vehiculo = p_placa AND hora_salida IS NULL) THEN
        RETURN QUERY SELECT false, 'El vehículo ya tiene un registro activo'::text, NULL::varchar, NULL::varchar;
        RETURN;
    END IF;

    -- Verificar si el cliente existe
    v_cliente_existe := EXISTS (SELECT 1 FROM tm_cliente WHERE pkc_cliente = p_cedula);
    
    -- Si no existe el cliente y se proporcionaron datos, crearlo
    IF NOT v_cliente_existe AND p_cedula IS NOT NULL AND p_nombre IS NOT NULL THEN
        INSERT INTO tm_cliente(pkc_cliente, nombre_cliente, apellido_cliente, telefono_cliente, fkcods_cliente)
        VALUES (p_cedula, p_nombre, COALESCE(p_apellido, ''), COALESCE(p_telefono, ''), 1);
    END IF;

    -- Verificar si el vehículo existe
    v_vehiculo_existe := EXISTS (SELECT 1 FROM tm_vehiculo WHERE pkplaca_vehiculo = p_placa);
    
    -- Si no existe el vehículo, crearlo
    IF NOT v_vehiculo_existe THEN
        INSERT INTO tm_vehiculo(pkplaca_vehiculo, detalle_vehiculo, fkid_tipo_vehiculo, fkc_cliente, fkcods_vehiculo)
        VALUES (p_placa, COALESCE(p_detalle_vehiculo, 'No especificado'), p_tipo_vehiculo, p_cedula, 1);
    END IF;

    -- Obtener tarifa según tipo de servicio
    SELECT pkid_tarifa, valor_tarifa 
    INTO v_id_tarifa, v_monto
    FROM tm_tarifa
    WHERE fkid_tipo_vehiculo = p_tipo_vehiculo 
      AND fkcod_tipo_servicio = p_tipo_servicio
      AND fkcods_tarifa = 1
    LIMIT 1;

    IF v_id_tarifa IS NULL THEN
        RETURN QUERY SELECT false, 'No se encontró tarifa para este servicio'::text, NULL::varchar, NULL::varchar;
        RETURN;
    END IF;

    -- Generar IDs únicos
    SELECT COUNT(*) + 1 INTO v_contador FROM td_pagos WHERE fecha_pago = CURRENT_DATE;
    v_id_pago := 'PAG' || LPAD(v_contador::text, 7, '0');
    
    SELECT COUNT(*) + 1 INTO v_contador FROM td_registros WHERE fecha_entrada = CURRENT_DATE;
    v_id_registro := 'REG' || LPAD(v_contador::text, 7, '0');

    -- Crear el pago
    INSERT INTO td_pagos(pkid_pago, fecha_pago, monto_pagado, fkc_cliente, fkcods_pagos)
    VALUES (v_id_pago, CURRENT_DATE, v_monto, COALESCE(p_cedula, '0000000000'), 3);

    -- Crear el registro
    INSERT INTO td_registros(
        pkid_registro, fecha_entrada, hora_entrada, fecha_salida, hora_salida,
        fkplaca_vehiculo, fkid_pago, fkc_empleado, fkid_tarifa, 
        fkcod_tipo_servicio, fkcods_registro
    ) VALUES (
        v_id_registro, CURRENT_DATE, CURRENT_TIME, NULL, NULL,
        p_placa, v_id_pago, p_empleado, v_id_tarifa,
        p_tipo_servicio, 1
    );

    RETURN QUERY SELECT true, 'Vehículo registrado exitosamente'::text, v_id_registro, v_id_pago;
END;
$$ LANGUAGE plpgsql;

-- Función 2: Obtener información para cobro
SELECT 'Paso 03.04: Función fn_obtener_info_cobro .....................'  AS paso, pg_sleep(03);

CREATE OR REPLACE FUNCTION fn_obtener_info_cobro(p_placa varchar)
RETURNS TABLE(
    success boolean,
    mensaje text,
    registro_id varchar,
    placa varchar,
    tipo_vehiculo varchar,
    tipo_servicio varchar,
    cedula varchar,
    nombre varchar,
    telefono varchar,
    fecha_entrada date,
    hora_entrada time,
    tiempo_transcurrido interval,
    monto_a_cobrar numeric
) AS $$
DECLARE
    v_registro RECORD;
    v_monto numeric(15,2);
BEGIN
    -- Buscar registro activo
    SELECT 
        r.pkid_registro,
        r.fkplaca_vehiculo,
        r.fecha_entrada,
        r.hora_entrada,
        r.fkcod_tipo_servicio,
        tv.detalle_tipo_vehiculo,
        ts.detalle_tipo_servicio,
        v.fkid_tipo_vehiculo,
        COALESCE(c.pkc_cliente, '') as cedula,
        COALESCE(c.nombre_cliente, '') as nombre,
        COALESCE(c.telefono_cliente, '') as telefono
    INTO v_registro
    FROM td_registros r
    LEFT JOIN tm_vehiculo v ON r.fkplaca_vehiculo = v.pkplaca_vehiculo
    LEFT JOIN tm_tipo_vehiculo tv ON v.fkid_tipo_vehiculo = tv.pkid_tipo_vehiculo
    LEFT JOIN tm_tipo_servicio ts ON r.fkcod_tipo_servicio = ts.pkcod_tipo_servicio
    LEFT JOIN tm_cliente c ON v.fkc_cliente = c.pkc_cliente
    WHERE r.fkplaca_vehiculo = p_placa 
      AND r.hora_salida IS NULL
    LIMIT 1;

    IF NOT FOUND THEN
        RETURN QUERY SELECT 
            false, 
            'No se encontró registro activo para esta placa'::text,
            NULL::varchar, NULL::varchar, NULL::varchar, NULL::varchar,
            NULL::varchar, NULL::varchar, NULL::varchar,
            NULL::date, NULL::time, NULL::interval, NULL::numeric;
        RETURN;
    END IF;

    -- Calcular monto usando la función existente
    v_monto := fcalcular_tarifa(
        v_registro.fecha_entrada,
        v_registro.hora_entrada,
        CURRENT_DATE,
        CURRENT_TIME,
        v_registro.fkid_tipo_vehiculo,
        v_registro.fkcod_tipo_servicio
    );

    RETURN QUERY SELECT 
        true,
        'Información obtenida correctamente'::text,
        v_registro.pkid_registro,
        v_registro.fkplaca_vehiculo,
        v_registro.detalle_tipo_vehiculo,
        v_registro.detalle_tipo_servicio,
        v_registro.cedula,
        v_registro.nombre,
        v_registro.telefono,
        v_registro.fecha_entrada,
        v_registro.hora_entrada,
        (CURRENT_TIMESTAMP - (v_registro.fecha_entrada + v_registro.hora_entrada)::timestamp)::interval,
        v_monto;
END;
$$ LANGUAGE plpgsql;

-- Función 3: Procesar cobro y salida del vehículo
SELECT 'Paso 03.05: Función fn_cobrar_cliente .....................'  AS paso, pg_sleep(03);

CREATE OR REPLACE FUNCTION fn_cobrar_cliente(
    p_placa varchar,
    p_monto numeric,
    p_empleado varchar DEFAULT '1234567890'
) RETURNS TABLE(
    success boolean,
    mensaje text,
    registro_id varchar,
    monto_final numeric
) AS $$
DECLARE
    v_registro_id varchar(10);
    v_pago_id varchar(10);
BEGIN
    -- Buscar registro activo
    SELECT pkid_registro, fkid_pago 
    INTO v_registro_id, v_pago_id
    FROM td_registros
    WHERE fkplaca_vehiculo = p_placa 
      AND hora_salida IS NULL
    LIMIT 1;

    IF v_registro_id IS NULL THEN
        RETURN QUERY SELECT false, 'No se encontró registro activo'::text, NULL::varchar, NULL::numeric;
        RETURN;
    END IF;

    -- Actualizar el registro con hora de salida
    UPDATE td_registros
    SET fecha_salida = CURRENT_DATE,
        hora_salida = CURRENT_TIME,
        fkc_empleado = p_empleado,
        fkcods_registro = 2
    WHERE pkid_registro = v_registro_id;

    -- Actualizar el pago
    UPDATE td_pagos
    SET monto_pagado = p_monto,
        fkcods_pagos = CASE 
            WHEN p_monto >= (SELECT valor_tarifa FROM tm_tarifa t 
                            JOIN td_registros r ON t.pkid_tarifa = r.fkid_tarifa 
                            WHERE r.pkid_registro = v_registro_id)
            THEN 4 
            ELSE 3 
        END
    WHERE pkid_pago = v_pago_id;

    RETURN QUERY SELECT true, 'Cobro procesado correctamente'::text, v_registro_id, p_monto;
END;
$$ LANGUAGE plpgsql;

-- Función 4: Obtener ingresos del día
SELECT 'Paso 03.06: Función fn_obtener_ingresos_dia .....................'  AS paso, pg_sleep(03);

CREATE OR REPLACE FUNCTION fn_obtener_ingresos_dia(p_fecha date DEFAULT CURRENT_DATE)
RETURNS TABLE(
    fecha date,
    total_ingresos numeric,
    cantidad_pagos integer,
    cantidad_carros integer,
    cantidad_motos integer
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        p_fecha,
        COALESCE(SUM(p.monto_pagado), 0) as total_ingresos,
        COUNT(p.pkid_pago)::integer as cantidad_pagos,
        COUNT(CASE WHEN v.fkid_tipo_vehiculo = 1000 THEN 1 END)::integer as cantidad_carros,
        COUNT(CASE WHEN v.fkid_tipo_vehiculo = 2000 THEN 1 END)::integer as cantidad_motos
    FROM td_pagos p
    LEFT JOIN td_registros r ON p.pkid_pago = r.fkid_pago
    LEFT JOIN tm_vehiculo v ON r.fkplaca_vehiculo = v.pkplaca_vehiculo
    WHERE p.fecha_pago = p_fecha;
END;
$$ LANGUAGE plpgsql;

-- Vista adicional: Historial del día
SELECT 'Paso 05.03: Vista v_historial_dia .....................'  AS paso, pg_sleep(03);

CREATE OR REPLACE VIEW v_historial_dia AS
SELECT 
    r.pkid_registro,
    r.fecha_entrada,
    r.hora_entrada,
    r.fecha_salida,
    r.hora_salida,
    v.pkplaca_vehiculo AS placa,
    tv.detalle_tipo_vehiculo AS tipo_vehiculo,
    ts.detalle_tipo_servicio AS tipo_servicio,
    COALESCE(c.nombre_cliente, 'Sin cliente') AS nombre_cliente,
    p.monto_pagado,
    e.detalle_estado AS estado
FROM td_registros r
LEFT JOIN tm_vehiculo v ON r.fkplaca_vehiculo = v.pkplaca_vehiculo
LEFT JOIN tm_tipo_vehiculo tv ON v.fkid_tipo_vehiculo = tv.pkid_tipo_vehiculo
LEFT JOIN tm_tipo_servicio ts ON r.fkcod_tipo_servicio = ts.pkcod_tipo_servicio
LEFT JOIN tm_cliente c ON v.fkc_cliente = c.pkc_cliente
LEFT JOIN td_pagos p ON r.fkid_pago = p.pkid_pago
LEFT JOIN tm_estado e ON r.fkcods_registro = e.pkcods
WHERE r.fecha_entrada = CURRENT_DATE
ORDER BY r.fecha_entrada DESC, r.hora_entrada DESC;
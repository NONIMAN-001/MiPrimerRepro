// ========== ELEMENTOS DEL DOM ==========
const tipoVehiculo = document.getElementById('tipo-vehiculo');
const tipoTiempo = document.getElementById('tipo-tiempo');
const inputSimple = document.getElementById('input-simple');
const inputFraccion = document.getElementById('input-fraccion');
const btnActualizar = document.getElementById('btn-actualizar');
const btnRegistrarVehiculo = document.getElementById('btn-registrar-vehiculo');

// Modal
const modal = document.getElementById('modal-contrasena');
const inputContrasena = document.getElementById('input-contrasena');
const btnConfirmar = document.getElementById('btn-confirmar-contrasena');
const btnCancelar = document.getElementById('btn-cancelar-contrasena');
const mensajeError = document.getElementById('mensaje-error');

const CONTRASENA_CORRECTA = '1234';

// ========== MOSTRAR/OCULTAR INPUTS SEGÚN SELECCIÓN ==========
tipoTiempo.addEventListener('change', function() {
    const valorSeleccionado = this.value;
    
    // Ocultar todos los inputs primero
    inputSimple.style.display = 'none';
    inputFraccion.style.display = 'none';
    
    // Mostrar el input correspondiente
    if (valorSeleccionado === 'fraccion') {
        inputFraccion.style.display = 'block';
    } else if (valorSeleccionado === 'dia' || valorSeleccionado === 'media-mensualidad' || valorSeleccionado === 'mes') {
        inputSimple.style.display = 'block';
        
        // Cambiar el label según el tipo seleccionado
        const label = inputSimple.querySelector('label');
        if (valorSeleccionado === 'dia') {
            label.textContent = 'Valor por Día:';
        } else if (valorSeleccionado === 'media-mensualidad') {
            label.textContent = 'Valor por Media Mensualidad:';
        } else if (valorSeleccionado === 'mes') {
            label.textContent = 'Valor por Mes:';
        }
    }
});

// ========== BOTÓN REGISTRAR NUEVO VEHÍCULO ==========
btnRegistrarVehiculo.addEventListener('click', function() {
    const vehiculo = tipoVehiculo.value;
    const tiempo = tipoTiempo.value;
    
    if (!vehiculo) {
        alert('Por favor seleccione un tipo de vehículo');
        return;
    }
    
    if (!tiempo) {
        alert('Por favor seleccione un tipo de tiempo');
        return;
    }
    
    // Validar que se hayan ingresado valores
    if (tiempo === 'fraccion') {
        const val15 = document.getElementById('valor-15min').value;
        const val30 = document.getElementById('valor-30min').value;
        const val45 = document.getElementById('valor-45min').value;
        const val1h = document.getElementById('valor-1hora').value;
        
        if (!val15 || !val30 || !val45 || !val1h) {
            alert('Por favor complete todos los valores de fracción');
            return;
        }
        
        console.log(`Registrando ${vehiculo} - Fracción:`);
        console.log(`15 min: $${val15}`);
        console.log(`30 min: $${val30}`);
        console.log(`45 min: $${val45}`);
        console.log(`1 hora: $${val1h}`);
        
    } else {
        const valor = document.getElementById('valor-tarifa').value;
        
        if (!valor) {
            alert('Por favor ingrese el valor de la tarifa');
            return;
        }
        
        console.log(`Registrando ${vehiculo} - ${tiempo}: $${valor}`);
    }
    
    alert('¡Vehículo registrado exitosamente!');
    limpiarFormulario();
});

// ========== BOTÓN ACTUALIZAR (Abre Modal) ==========
btnActualizar.addEventListener('click', function() {
    const vehiculo = tipoVehiculo.value;
    const tiempo = tipoTiempo.value;
    
    if (!vehiculo || !tiempo) {
        alert('Por favor seleccione el tipo de vehículo y tiempo antes de actualizar');
        return;
    }
    
    // Mostrar modal
    modal.style.display = 'flex';
    inputContrasena.value = '';
    mensajeError.style.display = 'none';
    inputContrasena.focus();
});

// ========== CONFIRMAR CONTRASEÑA ==========
btnConfirmar.addEventListener('click', function() {
    const contrasenaIngresada = inputContrasena.value;
    
    if (contrasenaIngresada === CONTRASENA_CORRECTA) {
        // Contraseña correcta, proceder con actualización
        actualizarTarifas();
        cerrarModal();
    } else {
        // Contraseña incorrecta
        mensajeError.style.display = 'block';
        inputContrasena.value = '';
        inputContrasena.focus();
    }
});

// ========== CANCELAR MODAL ==========
btnCancelar.addEventListener('click', cerrarModal);

// Cerrar modal con tecla Escape
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && modal.style.display === 'flex') {
        cerrarModal();
    }
});

// Confirmar con Enter en el input de contraseña
inputContrasena.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        btnConfirmar.click();
    }
});

// ========== FUNCIÓN ACTUALIZAR TARIFAS ==========
function actualizarTarifas() {
    const vehiculo = tipoVehiculo.value;
    const tiempo = tipoTiempo.value;
    
    if (tiempo === 'fraccion') {
        const val15 = document.getElementById('valor-15min').value;
        const val30 = document.getElementById('valor-30min').value;
        const val45 = document.getElementById('valor-45min').value;
        const val1h = document.getElementById('valor-1hora').value;
        
        if (!val15 || !val30 || !val45 || !val1h) {
            alert('Por favor complete todos los valores de fracción');
            return;
        }
        
        console.log(`Actualizando ${vehiculo} - Fracción:`);
        console.log(`15 min: $${val15}`);
        console.log(`30 min: $${val30}`);
        console.log(`45 min: $${val45}`);
        console.log(`1 hora: $${val1h}`);
        
    } else {
        const valor = document.getElementById('valor-tarifa').value;
        
        if (!valor) {
            alert('Por favor ingrese el valor de la tarifa');
            return;
        }
        
        console.log(`Actualizando ${vehiculo} - ${tiempo}: $${valor}`);
    }
    
    alert('¡Tarifas actualizadas exitosamente!');
    limpiarFormulario();
}

// ========== FUNCIÓN CERRAR MODAL ==========
function cerrarModal() {
    modal.style.display = 'none';
    inputContrasena.value = '';
    mensajeError.style.display = 'none';
}

// ========== FUNCIÓN LIMPIAR FORMULARIO ==========
function limpiarFormulario() {
    tipoVehiculo.value = '';
    tipoTiempo.value = '';
    inputSimple.style.display = 'none';
    inputFraccion.style.display = 'none';
    
    // Limpiar todos los inputs
    document.getElementById('valor-tarifa').value = '';
    document.getElementById('valor-15min').value = '';
    document.getElementById('valor-30min').value = '';
    document.getElementById('valor-45min').value = '';
    document.getElementById('valor-1hora').value = '';
}
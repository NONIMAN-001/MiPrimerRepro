package com.mycompany.ejemplo1;

/**
 *
 * @author USUARIO
 */
public class Ejemplo1 {

    public static void main(String[] args) {
        
        Vendedor V1 = new vendedorPuerta("Juan", "1091969959", 1000000);
        Vendedor V2 = new vendedorTelemercadeo("Kevin", "1234567890", 1000000);
        
        System.out.println(V1.getNombre() + " con cedula " + V1.getCedula() + " gana comision: $" +  V1.calcularComision());
        System.out.println(V2.getNombre() + " con cedula " + V2.getCedula() + " gana comision: $" + V2.calcularComision());
        
        V1.setNombre("David");
        V2.setNombre("Julian");
        System.out.println(V1.getNombre() + " con cedula " + V1.getCedula() + " gana comision: $" +  V1.calcularComision());
        System.out.println(V2.getNombre() + " con cedula " + V2.getCedula() + " gana comision: $" + V2.calcularComision());
        
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejemplo1;

/**
 *
 * @author USUARIO
 */
public class vendedorPuerta extends Vendedor{
    
    public vendedorPuerta(String Nombre, String Cedula, float valorVenta){
            super (Nombre, Cedula, valorVenta);
    } 
    
    @Override
    
    public double calcularComision(){
        return getvalorVenta() * 0.25;
    }
}

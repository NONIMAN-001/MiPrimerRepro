/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejemplo1;

/**
 *
 * @author USUARIO
 */
public abstract class Vendedor {
    
    public String Nombre;
    public String Cedula;
    public float valorVenta;
    
    public Vendedor(String Nombre, String Cedula, float valorVenta){
        this.Nombre = Nombre;
        this.Cedula = Cedula;
        this.valorVenta = valorVenta;
    }
    
    public abstract double calcularComision();
    
    public String getNombre(){
        return Nombre;
    }
    
    public String getCedula(){
        return Cedula;
    }
    
    public double getvalorVenta(){
        return valorVenta;
    }
    
    public void setNombre(String Nombre){
        this.Nombre = Nombre;
    }
    
    public void setCedula(String Cedula){
        this.Cedula = Cedula;
    }
    
    public void setvalorVenta(float valorVenta){
        this.valorVenta = valorVenta;
    }
}

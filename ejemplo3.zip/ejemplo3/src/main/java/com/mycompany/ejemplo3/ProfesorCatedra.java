/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejemplo3;

/**
 *
 * @author USUARIO
 */
import java.util.Scanner;
public class ProfesorCatedra extends Persona{
    int horas_trabajadas;
    double valor_hora;
    double salario;
    
    public ProfesorCatedra (String id, String nombre, int edad){
        super (id, nombre, edad);
    }
    
    public void Calificar(){
        System.out.println("El profesor " + nombre + " esta calificando trabajos");
    }
    
    public void subirNotas(){
        System.out.println("El profesor " + nombre + " esta subiendo notas");
    }
    
    public void dictarClase(){
        System.out.println("El profesor " + nombre + " esta dictando clase");
    }
    
    @Override
    public double calcularSalario() {
      Scanner scaner = new Scanner(System.in);
        
      System.out.print("Numero de horas trabajadas: ");
      horas_trabajadas = scaner.nextInt();
      
      System.out.print("Valor de cada hora: ");
      valor_hora = scaner.nextDouble();
      
      salario = valor_hora * horas_trabajadas;
      return salario;
    }

    @Override
    public void mostrarSalario() {
        System.out.printf("El salario del profesor %s es: %,.0f%n", nombre, salario);
    }
}

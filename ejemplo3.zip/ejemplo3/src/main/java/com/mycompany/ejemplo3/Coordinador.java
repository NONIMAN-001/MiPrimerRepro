/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejemplo3;

/**
 *
 * @author USUARIO
 */
import java.util.Scanner;
public class Coordinador extends Persona{
    
    double salario_fijo;
    double salario;
    
    public Coordinador(String id, String nombre, int edad){
        super(id, nombre, edad);
    }
    
    public void Supervisar(){
        System.out.println("El coordinador " + nombre + " esta supervisando");
    }
    
    public void asignarMaterias(){
        System.out.println("El coordinador " + nombre + " esta asignando materias");
    }
    
    public void firmarActas(){
        System.out.println("El coordinador " + nombre + " esta firmando actas");
    }
    
    @Override
    public double calcularSalario(){
        
        Scanner scaner = new Scanner(System.in);
        
        System.out.print("salario fijo: ");
        salario_fijo = scaner.nextDouble();
        
        salario = salario_fijo;
        return salario;
    }
    
    @Override
    public void mostrarSalario() {
        System.out.printf("El salario del coordinador %s es: %,.0f%n", nombre, salario);
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejemplo3;

/**
 *
 * @author USUARIO
 */
import java.util.Scanner;
public class Rector extends Persona {
    
    double salario_fijo;
    double salario;
    
    public Rector (String id, String nombre, int edad){
        super(id, nombre, edad);
    }
    
    public void manejarPresupuesto(){
        System.out.println("El rector " + nombre + " esta manejando presupuesto");
    }
   
    public void realizarReuniones(){
        System.out.println("El rector " + nombre + " esta en una reunion");
    }
    
    @Override
    public double calcularSalario() {
        
        Scanner scaner = new Scanner(System.in);
        
        System.out.print("salario fijo: ");
        salario_fijo = scaner.nextDouble();
        
        salario = salario_fijo;
        return salario;
    }
    
    @Override
    public void mostrarSalario() {
        System.out.printf("El salario del rector %s es: %,.0f%n", nombre, salario);
    }
}

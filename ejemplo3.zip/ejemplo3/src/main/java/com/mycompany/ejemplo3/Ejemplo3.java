/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejemplo3;

/**
 *
 * @author USUARIO
 */
import java.util.Scanner;

public class Ejemplo3 {
    
    public static void main(String[] args) {
       
        Scanner scanner = new Scanner(System.in);
        int accion;
        
        System.out.print("Cantidad de profesores: ");
        int cantProfesores = scanner.nextInt();
        
        System.out.print("Cantidad de coordinadores: ");
        int cantCoordinador = scanner.nextInt();
        
        System.out.print("Cantidad de secretarias: ");
        int cantSecretarias = scanner.nextInt();
        
        int cantRector = 1; 
        
        System.out.println("----------------------------------------------------------------------------");
        
        // ============================
        // PROFESORES
        // ============================
        for (int i = 1; i <= cantProfesores; i++) {
            System.out.println("\nProfesor #" + i);
            
            scanner.nextLine(); // limpiar buffer
            System.out.print("ID del profesor: ");
            String id = scanner.nextLine();
            
            System.out.print("Nombre del profesor: ");
            String nombre = scanner.nextLine();
            
            System.out.print("Edad del profesor: ");
            int edad = scanner.nextInt();
            
            System.out.println("Seleccione tipo de profesor:");
            System.out.println("1. Profesor de Catedra");
            System.out.println("2. Profesor de Planta");
            System.out.println("3. Profesor Ocasional");
            System.out.print("Opcion: ");
            int tipo_profesor = scanner.nextInt();
           
            Persona profesor = null;
            
            if (tipo_profesor == 1) {
                profesor = new ProfesorCatedra(id, nombre, edad);
                System.out.println("1 Calificar, 2 Subir notas, 3 dictar clase");
                accion = scanner.nextInt();
                
                if(accion == 1){
                   ProfesorCatedra profesorcatedra = (ProfesorCatedra) profesor;
                   profesorcatedra.Calificar();
                }
                else if(accion == 2){
                   ProfesorCatedra profesorcatedra = (ProfesorCatedra) profesor;
                   profesorcatedra.subirNotas();
                }
                else if (accion == 3){
                   ProfesorCatedra profesorcatedra = (ProfesorCatedra) profesor;
                   profesorcatedra.dictarClase();
                }
                else{
                    System.out.println("el tipo de accion no es valida.");
                    continue;
                }
                
            } else if (tipo_profesor == 2) {
                profesor = new ProfesorPlanta(id, nombre, edad);
                System.out.println("1 Calificar, 2 Subir notas, 3 dictar clase");
                accion = scanner.nextInt();
                
                if(accion == 1){
                   ProfesorPlanta profesorplanta = (ProfesorPlanta) profesor;
                   profesorplanta.Calificar();
                }
                else if(accion == 2){
                   ProfesorPlanta profesorplanta = (ProfesorPlanta) profesor;
                   profesorplanta.subirNotas();
                }
               else if (accion == 3){
                   ProfesorPlanta profesorplanta = (ProfesorPlanta) profesor;
                   profesorplanta.dictarClase();
                }
                else{
                    System.out.println("el tipo de accion no es valida.");
                    continue;
                }
                
            } else if (tipo_profesor == 3) {
                profesor = new ProfesorOcasional(id, nombre, edad);
                System.out.println("1 Calificar, 2 Subir notas, 3 dictar clase");
                accion = scanner.nextInt();
                
                if(accion == 1){
                   ProfesorOcasional profesorocasional = (ProfesorOcasional) profesor;
                   profesorocasional.Calificar();
                }
                else if(accion == 2){
                   ProfesorOcasional profesorocasional = (ProfesorOcasional) profesor;
                   profesorocasional.subirNotas();
                }
               else if (accion == 3){
                   ProfesorOcasional profesorocasional = (ProfesorOcasional) profesor;
                   profesorocasional.dictarClase();
                }
                else{
                    System.out.println("el tipo de accion no es valida.");
                    continue;
                }
                
            } else {
                System.out.println("Tipo de profesor no válido.");
                continue;
            }
            
            profesor.calcularSalario();
            profesor.mostrarSalario();
            System.out.println("\n----------------------------------------------------");
        }
        
        // ============================
        // COORDINADORES
        // ============================
        for (int i = 1; i <= cantCoordinador; i++) {
            System.out.println("\nCoordinador #" + i);
            scanner.nextLine(); 
            
            System.out.print("ID: ");
            String id = scanner.nextLine();
            System.out.print("Nombre: ");
            String nombre = scanner.nextLine();
            System.out.print("Edad: ");
            int edad = scanner.nextInt();
            
            Coordinador coordinador = new Coordinador(id, nombre, edad);
            
            System.out.println("1 supervisar, 2 asignar materias, 3 firmar actas");
            accion = scanner.nextInt();
                
                if(accion == 1){
                   coordinador.Supervisar();
                }
                else if(accion == 2){
                   coordinador.asignarMaterias();
                }
               else if (accion == 3){
                   coordinador.firmarActas();
                }
                else{
                    System.out.println("el tipo de accion no es valida.");
                    continue;
                }
           
            coordinador.calcularSalario();
            coordinador.mostrarSalario();
            System.out.println("\n----------------------------------------------------");
        }
        
        // ============================
        // SECRETARIAS
        // ============================
        for (int i = 1; i <= cantSecretarias; i++) {
            System.out.println("\nSecretaria #" + i);
            scanner.nextLine();
            
            System.out.print("ID: ");
            String id = scanner.nextLine();
            System.out.print("Nombre: ");
            String nombre = scanner.nextLine();
            System.out.print("Edad: ");
            int edad = scanner.nextInt();
            
            Secretaria secretaria = new Secretaria(id, nombre, edad);
            
            System.out.println("1 agendar reunion, 2 recoger listas");
            accion = scanner.nextInt();
                
                if(accion == 1){
                   secretaria.agendarReuniones();
                }
                else if(accion == 2){
                   secretaria.recogerListas();
                }
                else{
                    System.out.println("el tipo de accion no es valida.");
                    continue;
                }
                
            secretaria.calcularSalario();
            secretaria.mostrarSalario();
            System.out.println("\n----------------------------------------------------");
        }
        
        // ============================
        // RECTOR
        // ============================
        for (int i = 1; i <= cantRector; i++) {
            System.out.println("\nRector #" + i);
            scanner.nextLine();
            
            System.out.print("ID: ");
            String id = scanner.nextLine();
            System.out.print("Nombre: ");
            String nombre = scanner.nextLine();
            System.out.print("Edad: ");
            int edad = scanner.nextInt();
            
            Rector rector = new Rector(id, nombre, edad);
            
            System.out.println("1 manejar presupuesto, 2 realizar reuniones");
            accion = scanner.nextInt();
                
                if(accion == 1){
                   rector.manejarPresupuesto();
                }
                else if(accion == 2){
                   rector.realizarReuniones();
                }
                else{
                    System.out.println("el tipo de accion no es valida.");
                    continue;
                }
                
            rector.calcularSalario();
            rector.mostrarSalario();
            System.out.println("\n----------------------------------------------------");
        }
        
        scanner.close();
        System.out.println("\nFin del programa.");
    }
}

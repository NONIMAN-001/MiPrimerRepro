/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejemplo3;

/**
 *
 * @author USUARIO
 */
public abstract class Persona {
    
    String id;
    String nombre;
    int edad;
    
    public Persona(String id, String nombre, int edad){
        this.id = id;
        this.nombre = nombre;
        this.edad = edad;
    }
    
    public String getid(){
        return id;
    }
    
    public String getnombre(){
        return nombre;
    }
    
    public int getedad(){
       return edad; 
    }
    
    public void setid (String id){
        this.id = id;
    }
    
    public void setnombre (String nombre){
        this.nombre = nombre;
    }
    
    public void setedad (int edad){
        this.edad = edad;
    }
    
    public abstract double calcularSalario();
    
    public abstract void mostrarSalario();
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany;

/**
 *
 * @author USUARIO
 */
public class Cuenta {
    
    public long numero_cuenta;
    public String fecha_apertura;
    public int tipo_cuenta;
    public double saldo_cuenta;
    int get;
    
    public Cuenta(long numero_cuenta, String fecha_apertura, int tipo_cuenta, double saldo_cuenta){
        this.numero_cuenta = numero_cuenta;
        this.fecha_apertura = fecha_apertura;
        this.tipo_cuenta = tipo_cuenta;
        this.saldo_cuenta = saldo_cuenta;
    }
    
    public long getnumero_cuenta(){
        return numero_cuenta;
    }
    
    public String getfecha_apertura(){
        return fecha_apertura;
    }
    
    public int gettipo_cuenta(){
        return tipo_cuenta;
    }
    
    public double getsaldo_cuenta(){
        return saldo_cuenta;
    }
    
    public void setnumero_cuenta(long numero_cuenta){
        this.numero_cuenta = numero_cuenta;
    }
    
    public void setfecha_apertura(String fecha_apertura){
        this.fecha_apertura = fecha_apertura;
    }
    
    public void settipo_cuenta(int tipo_cuenta){
        this.tipo_cuenta = tipo_cuenta;
    }
    
    public void setsaldo_cuenta(long saldo_cuenta){
        this.saldo_cuenta = saldo_cuenta;
    }
    
    public double calcularIntereses(){
        
        double valor_interes;
        if (tipo_cuenta == 1){
            System.out.println("Ahorro Diario ");
            valor_interes = saldo_cuenta * 0.015;
        }
        else if (tipo_cuenta == 2){
            System.out.println("Cuenta Joven ");
            valor_interes = saldo_cuenta * 0.017;
        }
        else {
            System.out.println("Tradiccional ");
            valor_interes = saldo_cuenta * 0.016;
        }
        return valor_interes;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany;
/**
 *
 * @author USUARIO
 */
public class Ejercicio1B {

    public static void main(String[] args) {
        
        Cuenta C1 = new Cuenta(123, "18/10/2025", 2, 1000);
        Cuenta C2 = new Cuenta(234, "18/10/2025", 1, 2000);
        Cuenta C3 = new Cuenta(345, "18/10/2025", 3, 3000);
        
        System.out.println("========= CUENTA 1 =========");
        System.out.println("Número de cuenta: " + C1.getnumero_cuenta());
        System.out.println("Fecha de apertura: " + C1.getfecha_apertura());
        System.out.println("Tipo de cuenta: " + C1.gettipo_cuenta());
        System.out.println("Saldo: " + C1.getsaldo_cuenta());
        System.out.println("Valor del interés: " + C1.calcularIntereses());
        System.out.println(); // salto de línea

        System.out.println("========= CUENTA 2 =========");
        System.out.println("Número de cuenta: " + C2.getnumero_cuenta());
        System.out.println("Fecha de apertura: " + C2.getfecha_apertura());
        System.out.println("Tipo de cuenta: " + C2.gettipo_cuenta());
        System.out.println("Saldo: " + C2.getsaldo_cuenta());
        System.out.println("Valor del interés: " + C2.calcularIntereses());
        System.out.println();

        System.out.println("========= CUENTA 3 =========");
        System.out.println("Número de cuenta: " + C3.getnumero_cuenta());
        System.out.println("Fecha de apertura: " + C3.getfecha_apertura());
        System.out.println("Tipo de cuenta: " + C3.gettipo_cuenta());
        System.out.println("Saldo: " + C3.getsaldo_cuenta());
        System.out.println("Valor del interés: " + C3.calcularIntereses());
    }
}

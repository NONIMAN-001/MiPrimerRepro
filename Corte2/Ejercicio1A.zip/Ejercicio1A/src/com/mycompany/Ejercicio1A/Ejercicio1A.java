/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.Ejercicio1A;

/**
 *
 * @author USUARIO
 */
import java.util.Scanner;
public class Ejercicio1A {
   
    public static void main(String[] args){
        
        Scanner scanner = new Scanner(System.in);
        double interes_mensual;
        long num_cuenta;
        String fecha_apertura;
        double saldo_cuenta;
        int tipo_cuenta;
        double suma_saldo;
        double valor_total_intereses = 0;
        double valor_total_saldos = 0;
        System.out.print("Cantidad total de cuentas: ");
        int Total_cuentas = scanner.nextInt();
        int cuenta = 1;
        
        while(cuenta <= Total_cuentas){

            System.out.println("--------------------------------------------");
            System.out.print("Numero de la cuenta: ");
            num_cuenta = scanner.nextInt();
            
            scanner.nextLine();
            System.out.print("Fecha de apertura (DD/MM/AAAA): ");
            fecha_apertura = scanner.nextLine();

            System.out.println("1 Ahorro Diario, 2 Cuenta Joven, 3 Tradiccional");
            System.out.print("Tipo de cuenta: ");
            tipo_cuenta = scanner.nextInt();

            System.out.print("Saldo de la cuenta: ");
            saldo_cuenta = scanner.nextDouble();


            if (tipo_cuenta == 1){
                interes_mensual = (saldo_cuenta * 0.015);
                System.out.print("interes mensual: ");
                System.out.println(interes_mensual);
                suma_saldo = (saldo_cuenta + interes_mensual);
                System.out.print("Saldo de la cuenta + el interes mensual: ");
                System.out.println(suma_saldo);
            }
            else if (tipo_cuenta == 2){
                interes_mensual = (saldo_cuenta * 0.017);
                System.out.print("interes mensual: ");
                System.out.println(interes_mensual);
                System.out.print("Saldo de la cuenta + el interes mensual: ");
                suma_saldo = (saldo_cuenta + interes_mensual);
                System.out.println(suma_saldo);
            }
            else{
                interes_mensual = (saldo_cuenta * 0.016);
                System.out.print("interes mensual: ");
                System.out.println(interes_mensual);
                System.out.print("Saldo de la cuenta + el interes mensual: ");
                suma_saldo = (saldo_cuenta + interes_mensual);
                System.out.println(suma_saldo);
            }
            
            valor_total_intereses = interes_mensual + valor_total_intereses;
            valor_total_saldos = suma_saldo + valor_total_saldos;
            cuenta = cuenta + 1;
        }
        System.out.print("Valor total de los intereses: ");
        System.out.println(valor_total_intereses);
        System.out.print("Valor total de los saldos: ");
        System.out.println(valor_total_saldos);
    }
}


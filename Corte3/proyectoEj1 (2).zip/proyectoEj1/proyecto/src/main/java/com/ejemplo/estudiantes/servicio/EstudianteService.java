package com.ejemplo.estudiantes.servicio;

import com.ejemplo.estudiantes.modelo.Estudiante;
import com.ejemplo.estudiantes.repositorio.EstudianteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EstudianteService {

	@Autowired
	private EstudianteRepository estudianteRepository;

	public List<Estudiante> listarEstudiantes() {
		return estudianteRepository.findAll();
	}

	public Optional<Estudiante> buscarPorId(int id) {
		return estudianteRepository.findById(id);
	}

	public Estudiante registrarEstudiante(Estudiante estudiante) {
		return estudianteRepository.save(estudiante);
	}

	public Optional<Estudiante> actualizarEstudiante(int id, Estudiante estudianteActualizado) {
		return estudianteRepository.findById(id).map(estudiante -> {
			if (estudianteActualizado.getNombre() != null) {
				estudiante.setNombre(estudianteActualizado.getNombre());
			}
			if (estudianteActualizado.getApellido_estudiante() != null) {
				estudiante.setApellido_estudiante(estudianteActualizado.getApellido_estudiante());
			}
			if (estudianteActualizado.getEdad() > 0) {
				estudiante.setEdad(estudianteActualizado.getEdad());
			}
			if (estudianteActualizado.getFkcodsta() > 0) {
				estudiante.setFkcodsta(estudianteActualizado.getFkcodsta());
			}
			return estudianteRepository.save(estudiante);
		});
	}

	public boolean eliminarEstudiante(int id) {
		if (estudianteRepository.existsById(id)) {
			estudianteRepository.deleteById(id);
			return true;
		} else {
			return false;
		}
	}
}

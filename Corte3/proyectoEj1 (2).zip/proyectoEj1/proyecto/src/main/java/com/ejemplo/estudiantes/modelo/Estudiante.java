package com.ejemplo.estudiantes.modelo;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import java.util.Objects;

@Entity
@Table(name = "tmestudiantes")
public class Estudiante {

	@Id
	private Integer pkid_estudiante;

	@NotBlank(message = "El nombre no puede estar vacío")
	private String nombre_estudiante;

	@NotBlank(message = "El apellido no puede estar vacío")
	private String apellido_estudiante;

	@Min(value = 0, message = "La edad debe ser mayor o igual a 0")
	private int edad_estudiante;

	private int fkcodsta; // Relación con tmestados

	public Estudiante() {
	}

	public Estudiante(int pkid_estudiante, String nombre_estudiante, String apellido_estudiante,
			int edad_estudiante, int fkcodsta) {
		this.pkid_estudiante = pkid_estudiante;
		this.nombre_estudiante = nombre_estudiante;
		this.apellido_estudiante = apellido_estudiante;
		this.edad_estudiante = edad_estudiante;
		this.fkcodsta = fkcodsta;
	}

	// Getters y Setters
	public int getPkid_estudiante() {
		return pkid_estudiante;
	}

	public void setPkid_estudiante(int pkid_estudiante) {
		this.pkid_estudiante = pkid_estudiante;
	}

	public String getNombre_estudiante() {
		return nombre_estudiante;
	}

	public void setNombre_estudiante(String nombre_estudiante) {
		this.nombre_estudiante = nombre_estudiante;
	}

	public String getApellido_estudiante() {
		return apellido_estudiante;
	}

	public void setApellido_estudiante(String apellido_estudiante) {
		this.apellido_estudiante = apellido_estudiante;
	}

	public int getEdad_estudiante() {
		return edad_estudiante;
	}

	public void setEdad_estudiante(int edad_estudiante) {
		this.edad_estudiante = edad_estudiante;
	}

	public int getFkcodsta() {
		return fkcodsta;
	}

	public void setFkcodsta(int fkcodsta) {
		this.fkcodsta = fkcodsta;
	}

	// Métodos adicionales para compatibilidad con servicios/controlador existentes
	public int getId_estudiante() {
		return this.pkid_estudiante;
	}

	public void setId_estudiante(int id) {
		this.pkid_estudiante = id;
	}

	public String getNombre() {
		return this.nombre_estudiante;
	}

	public void setNombre(String nombre) {
		this.nombre_estudiante = nombre;
	}

	public String getApellido() {
		return this.apellido_estudiante;
	}

	public void setApellido(String apellido) {
		this.apellido_estudiante = apellido;
	}

	public int getEdad() {
		return this.edad_estudiante;
	}

	public void setEdad(int edad) {
		this.edad_estudiante = edad;
	}

	// equals y hashCode
	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof Estudiante))
			return false;
		Estudiante that = (Estudiante) o;
		return pkid_estudiante == that.pkid_estudiante &&
				edad_estudiante == that.edad_estudiante &&
				fkcodsta == that.fkcodsta &&
				Objects.equals(nombre_estudiante, that.nombre_estudiante) &&
				Objects.equals(apellido_estudiante, that.apellido_estudiante);
	}

	@Override
	public int hashCode() {
		return Objects.hash(pkid_estudiante, nombre_estudiante, apellido_estudiante, edad_estudiante, fkcodsta);
	}

	@Override
	public String toString() {
		return "Estudiante{" +
				"pkid_estudiante=" + pkid_estudiante +
				", nombre_estudiante='" + nombre_estudiante + '\'' +
				", apellido_estudiante='" + apellido_estudiante + '\'' +
				", edad_estudiante=" + edad_estudiante +
				", fkcodsta=" + fkcodsta +
				'}';
	}
}

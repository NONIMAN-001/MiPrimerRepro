package com.ejemplo.estudiantes.servicio;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import org.springframework.stereotype.Service;
import com.ejemplo.estudiantes.modelo.Estudiante;

@Service
public class EstudianteService {
	private final List<Estudiante> estudiantes = new ArrayList<>();
	private final AtomicInteger proximoId = new AtomicInteger(3);

	public EstudianteService() {
		estudiantes.add(new Estudiante(1, "Juan Pérez", 20));
		estudiantes.add(new Estudiante(2, "María López", 21));
	}

	public List<Estudiante> listarEstudiantes() {
		return List.copyOf(estudiantes);
	}

	public Optional<Estudiante> buscarPorId(int id) {
		return estudiantes.stream().filter(e -> e.getId() == id).findFirst();
	}

	public Estudiante registrarEstudiante(Estudiante estudiante) {
		if (estudiante == null) {
			throw new IllegalArgumentException("Estudiante no puede ser null");
		}
		estudiante.setId(proximoId.getAndIncrement());
		estudiantes.add(estudiante);
		return estudiante;
	}

	public Optional<Estudiante> actualizarEstudiante(int id, Estudiante estudianteActualizado) {
		return buscarPorId(id).map(estudiante -> {
			estudiante.setNombre(estudianteActualizado.getNombre());
			estudiante.setEdad(estudianteActualizado.getEdad());
			return estudiante;
		});
	}

	public boolean eliminarEstudiante(int id) {
		return estudiantes.removeIf(e -> e.getId() == id);
	}
}

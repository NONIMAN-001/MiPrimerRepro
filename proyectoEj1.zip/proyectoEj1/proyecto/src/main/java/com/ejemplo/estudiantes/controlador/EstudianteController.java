package com.ejemplo.estudiantes.controlador;

import java.net.URI;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ejemplo.estudiantes.modelo.Estudiante;
import com.ejemplo.estudiantes.servicio.EstudianteService;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/estudiantes")
@CrossOrigin(origins = "*")
@Validated
public class EstudianteController {

	@Autowired
	private EstudianteService estudianteService;

	@GetMapping
	public ResponseEntity<List<Estudiante>> listarEstudiantes() {
		return ResponseEntity.ok(estudianteService.listarEstudiantes());
	}

	@GetMapping("/{id}")
	public ResponseEntity<Estudiante> buscarEstudiante(@PathVariable int id) {
		return estudianteService.buscarPorId(id)
				.map(ResponseEntity::ok)
				.orElse(ResponseEntity.notFound().build());
	}

	@PostMapping
	public ResponseEntity<Estudiante> registrarEstudiante(@Valid @RequestBody Estudiante estudiante) {
		Estudiante creado = estudianteService.registrarEstudiante(estudiante);
		URI location = URI.create(String.format("/estudiantes/%d", creado.getId()));
		return ResponseEntity.created(location).body(creado);
	}

	@PutMapping("/{id}")
	public ResponseEntity<Estudiante> actualizarEstudiante(@PathVariable int id,
			@Valid @RequestBody Estudiante estudiante) {
		return estudianteService.actualizarEstudiante(id, estudiante)
				.map(ResponseEntity::ok)
				.orElse(ResponseEntity.notFound().build());
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> eliminarEstudiante(@PathVariable int id) {
		boolean eliminado = estudianteService.eliminarEstudiante(id);
		return eliminado ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
	}
}

package com.ejemplo.estudiantes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ProyectoApplicationTests {

	@Test
	public void contextLoads() {
	}

}
